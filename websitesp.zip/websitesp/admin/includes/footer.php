<div id = "footer"> <p>@SmartPhone Depot</p>
						<p> copyright © SmartPhone Depot</p>
			</div>