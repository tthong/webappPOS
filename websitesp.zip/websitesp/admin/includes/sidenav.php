<div id="sidenav">
			
			<h2 class = "texts">Main Feature</h2>
			<ul class = "lab">
				<li> <a href="index.php">Home</a></li>
				<li> <a href="createUserAccount.php">User Managerment</a></li>
				<li> <a href="onlinesellordered.php">Online Sales</a></li>
				<li> <a href="instoresell.php">In-store Sales</a></li>
				<li> <a href="products.php">Products</a></li>
				<li> <a href="addnewphonetype.php">Add New Phone Model</a></li>
				<li> <a href="purchase.php">Purchase</a></li>
				<li> <a href="expense.php">Expenses</a></li>
				<li> <a href="stock.php">Stock</a></li>
				<li> <a href="addnewModelphone.php">Add New Model Phone</a></li>
			</ul>
			
			<h2 class = "texts">Report</h2>
			<ul class ="lab">
				<li> <a href="salereport.php">Sales Report</a></li>
				<li> <a href="phonepurchasereport.php">Phone Purchase Report</a></li>
				<li> <a href="#">Phone Payment Report</a></li>
				<li> <a href="#">Sales Payment Report</a></li>
				<li> <a href="expensereport.php">Expense Report</a></li>
				<li> <a href="#">Customer Statment</a></li>
				<li> <a href="#">Profit/Loss Report</a></li>
				<li> <a href="#">Tax Report</a></li>
				<li> <a href="stockreport.php">Stock Report</a></li>
				<li> <a href="itemsreport.php">Items Report</a></li>
				<li> <a href="useractivityReport.php">User Activity Report</a></li>
			</ul>
		</div>