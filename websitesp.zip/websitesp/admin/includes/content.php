<div id="content">
	<h1>Welcome to POS Admin Dashboard</h1>
	<p>name:</p>
</div>