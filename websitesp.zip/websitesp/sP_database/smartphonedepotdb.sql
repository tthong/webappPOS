-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2020 at 03:12 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smartphonedepotdb`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `BASKET_ADDSMP_SP` (IN `p_basketitemid` INT(8), IN `p_producid` VARCHAR(16), IN `p_basketid` INT(8), IN `p_price` DOUBLE, IN `p_quantity` INT(5), IN `p_sizecode` INT(2), IN `p_fromcode` INT(2))  NO SQL
BEGIN
INSERT INTO sp_cartItem (idCartItem,idSmartPhones,price,Quantity,idCart,option1,option2)
VALUES (p_basketitemid, p_producid, p_price, p_quantity, p_basketid,p_sizecode,p_fromcode);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `basket_calc_sp` (IN `p_idCart` INT(8))  NO SQL
BEGIN
 declare lv_sub_num double;
 declare lv_tax_num double ;
 declare lv_ship_num double;
 declare lv_total_num double;
 declare lv_quantity_item int(5);
set lv_sub_num  = subtotal_calc_sf(p_idCart);
set lv_tax_num = tax_calc_sfuntion(p_idCart, subtotal_calc_sf(p_idCart));
set lv_ship_num = shipping_calc_sf(p_idCart);
set lv_total_num = (lv_sub_num + lv_tax_num + lv_ship_num);
select SUM(quantity)
into lv_quantity_item
 from sp_cartItem
 where idCart = p_idCart;
 UPDATE sp_cart
  SET orderplaced = 1,
      subtotal = lv_sub_num,
      Tax = lv_tax_num,
      shipping = lv_ship_num,
      quantity = lv_quantity_item,
      total = lv_total_num
  WHERE idCart = p_idCart;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cal_total_before_orderPlace_sp` (IN `p_idCart` INT(8))  NO SQL
BEGIN
 declare lv_sub_num double;
 declare lv_tax_num double ;
 declare lv_ship_num double;
 declare lv_total_num double;
 declare lv_quantity_item int(5);
set lv_sub_num  = subtotal_calc_sf(p_idCart);
set lv_tax_num = tax_calc_sfuntion(p_idCart, subtotal_calc_sf(p_idCart));
set lv_ship_num = shipping_calc_sf(p_idCart);
set lv_total_num = (lv_sub_num + lv_tax_num + lv_ship_num);
select SUM(quantity)
into lv_quantity_item
 from sp_cartItem
 where idCart = p_idCart;
 UPDATE sp_cart
  SET subtotal = lv_sub_num,
      Tax = lv_tax_num,
      shipping = lv_ship_num,
      quantity = lv_quantity_item,
      total = lv_total_num
  WHERE idCart = p_idCart;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Userlogin_sp` (IN `p_username` VARCHAR(25), IN `p_password` VARCHAR(100), OUT `username` VARCHAR(25), OUT `password` VARCHAR(100), OUT `shopperid` INT(8), OUT `firstname` VARCHAR(30))  NO SQL
BEGIN
DECLARE lv_firstName_txt VARCHAR(30);
DECLARE lv_lastName_txt VARCHAR(30);
DECLARE LV_RowNotFound INT(2) DEFAULT 0;
DECLARE lv_idshoper INT(8);
DECLARE CONTINUE HANDLER FOR NOT FOUND
set LV_RowNotFound = 1;
 SELECT idShopper, username, password, firstname
 INTO shopperid, username, password, firstname
 FROM sp_shopper
 WHERE username = p_username;

END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `shipping_calc_sf` (`f_idCart` INT(8)) RETURNS DOUBLE NO SQL
BEGIN
declare lv_qty_num int(5);
 declare lv_ship_cost double;
  SELECT SUM(quantity)
   INTO lv_qty_num
   FROM sp_cartitem
   WHERE idCart = f_idCart;
  IF lv_qty_num > 10 THEN
     set lv_ship_cost = 15.00;
  ELSEIF lv_qty_num > 5 THEN
     set lv_ship_cost = 8.00;
  ELSE
    set lv_ship_cost = 5.00;
  END IF;
  RETURN lv_ship_cost;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `subtotal_calc_sf` (`f_idcal` INT(8)) RETURNS DOUBLE NO SQL
BEGIN
 declare lv_sub_num double;
 SELECT SUM(quantity*price)
  INTO lv_sub_num
  FROM sp_cartitem
  WHERE idCart = f_idcal;
 RETURN round(lv_sub_num,2);
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `tax_calc_sfuntion` (`f_id` INT(8), `f_subtotal` DOUBLE) RETURNS DOUBLE NO SQL
BEGIN
declare lv_tax_num double;
 SELECT f_subtotal*t.taxrate tax
  INTO lv_tax_num
  FROM sp_cart b, sp_tax t
  WHERE b.shipstate = t.state
   AND b.idCart = f_id;
  RETURN ROUND(lv_tax_num,2);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `colors`
--

CREATE TABLE `colors` (
  `C_ID` int(11) NOT NULL,
  `C_DESC` varchar(100) NOT NULL,
  `C_HEX` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `colors`
--

INSERT INTO `colors` (`C_ID`, `C_DESC`, `C_HEX`) VALUES
(1, 'Gold', '#E8D8C1'),
(2, 'Silver', '#DCDCDC'),
(3, 'Space Gray', '#C2C3C8'),
(4, 'Rose Gold', '#F1C8C2'),
(5, 'Black', '#000');

-- --------------------------------------------------------

--
-- Table structure for table `loginadmin`
--

CREATE TABLE `loginadmin` (
  `idadmin` int(8) NOT NULL,
  `adminUsername` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `adminPassword` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `adminLevel` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `loginadmin`
--

INSERT INTO `loginadmin` (`idadmin`, `adminUsername`, `adminPassword`, `adminLevel`) VALUES
(29, 'user9', '25f9e794323b453885f5181f1b624d0b', 'admin'),
(31, 'smartphoneDepot', '25f9e794323b453885f5181f1b624d0b', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `phones`
--

CREATE TABLE `phones` (
  `P_ID` int(11) NOT NULL,
  `P_SKU` int(4) DEFAULT NULL,
  `P_MODEL` varchar(100) NOT NULL,
  `P_DESC` varchar(500) NOT NULL,
  `P_IMG` varchar(100) NOT NULL,
  `P_STATUS` char(1) NOT NULL DEFAULT 'Y',
  `P_FEATURED_START` date DEFAULT NULL,
  `P_FEATURED_END` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `phones`
--

INSERT INTO `phones` (`P_ID`, `P_SKU`, `P_MODEL`, `P_DESC`, `P_IMG`, `P_STATUS`, `P_FEATURED_START`, `P_FEATURED_END`) VALUES
(1, NULL, 'iPhone 6', 'Factory Unlocked\r\nApple A8 chip with M8 motion coprocessor\r\nSoftware version: iOS 12.4.4\r\n4G LTE speed\r\n4.7″ Retina touch screen with IPS technology\r\n8 MP rear-facing camera and front-facing 1.2 MP camera for self-portraits and video.\r\nCloud support lets you access your files anywhere\r\n\r\n', 'images/iPhone%206/space%20grey/front.jpg', 'Y', NULL, NULL),
(2, NULL, 'iPhone 6 Plus', 'Factory Unlocked\r\nApple A8 chip with M8 motion coprocessor\r\nSoftware version: iOS 12.4.4\r\n4G LTE speed\r\n5.5″ Retina touch screen with IPS technology\r\n8 MP rear-facing camera and front-facing 1.2 MP camera for self-portraits and video.\r\nCloud support lets you access your files anywhere\r\nTouch ID keeps your phone secure', 'images/iPhone%206%20Plus/gold/front.jpg', 'Y', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `phone_colors`
--

CREATE TABLE `phone_colors` (
  `PC_ID` int(11) NOT NULL,
  `PC_QUANTITY` int(11) NOT NULL,
  `P_OPT_ID` int(11) NOT NULL,
  `C_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `phone_colors`
--

INSERT INTO `phone_colors` (`PC_ID`, `PC_QUANTITY`, `P_OPT_ID`, `C_ID`) VALUES
(1, 67, 1, 1),
(2, 66, 1, 2),
(3, 67, 1, 3),
(4, 67, 2, 1),
(5, 66, 2, 2),
(6, 67, 2, 3),
(7, 67, 3, 1),
(8, 66, 3, 2),
(9, 67, 2, 1),
(10, 66, 2, 2),
(11, 67, 2, 3),
(12, 67, 3, 1),
(13, 66, 3, 2),
(14, 67, 3, 3),
(15, 67, 4, 1),
(16, 66, 4, 2),
(17, 67, 4, 3),
(18, 67, 5, 1),
(19, 66, 5, 2),
(20, 67, 5, 3),
(21, 67, 6, 1),
(22, 66, 6, 2),
(23, 67, 6, 3),
(24, 67, 7, 1),
(25, 66, 7, 2),
(26, 67, 7, 3),
(27, 67, 8, 1),
(28, 66, 8, 2),
(29, 67, 8, 3);

-- --------------------------------------------------------

--
-- Table structure for table `phone_grades`
--

CREATE TABLE `phone_grades` (
  `P_GRADE_ID` int(11) NOT NULL,
  `P_GRADE` char(1) NOT NULL,
  `P_GRADE_DESC` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `phone_grades`
--

INSERT INTO `phone_grades` (`P_GRADE_ID`, `P_GRADE`, `P_GRADE_DESC`) VALUES
(1, 'A', 'No Crack\r\nNo Chip\r\nNo Watermark\r\nNo Scratches\r\nNo Major Dent\r\nScratches Less Than 50%\r\nNo Engraving or Removed Engraving\r\nNo Visible Scratches on Screen\r\nVery Minimal Signs of Wear'),
(2, 'B', 'No Crack\r\nEdge Chip < 2.0mm Acceptable\r\nVisible Scratches Acceptable\r\nWatermark No Bigger Than a Dime Acceptable\r\nMinor Dent\r\nRemoved Engraving Acceptable\r\nSome Signs of Wear'),
(3, 'C', 'No Crack\r\nEdge Chip < 5.0mm Acceptable\r\nVisible Scratches\r\nPossible Dent\r\nHeavy Signs of Wear');

-- --------------------------------------------------------

--
-- Table structure for table `phone_options`
--

CREATE TABLE `phone_options` (
  `P_OPT_ID` int(11) NOT NULL,
  `P_PRICE` decimal(10,0) NOT NULL,
  `P_QUANTITY` int(11) NOT NULL,
  `P_OPT_SALE_ST` datetime DEFAULT NULL,
  `P_OPT_SALE_END` datetime DEFAULT NULL,
  `P_GRADE_ID` int(11) NOT NULL,
  `P_STG_ID` int(11) NOT NULL,
  `P_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `phone_options`
--

INSERT INTO `phone_options` (`P_OPT_ID`, `P_PRICE`, `P_QUANTITY`, `P_OPT_SALE_ST`, `P_OPT_SALE_END`, `P_GRADE_ID`, `P_STG_ID`, `P_ID`) VALUES
(1, '125', 200, NULL, NULL, 1, 1, 1),
(2, '150', 110, NULL, NULL, 1, 3, 1),
(3, '120', 200, NULL, NULL, 2, 1, 1),
(4, '140', 200, NULL, NULL, 2, 3, 1),
(5, '175', 198, NULL, NULL, 1, 1, 2),
(6, '160', 200, NULL, NULL, 2, 1, 2),
(7, '200', 199, NULL, NULL, 1, 3, 2),
(8, '185', 200, NULL, NULL, 2, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `phone_storage`
--

CREATE TABLE `phone_storage` (
  `P_STG_ID` int(11) NOT NULL,
  `P_STG_SIZE` int(11) NOT NULL,
  `P_STG_UNIT` char(2) NOT NULL DEFAULT 'GB'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `phone_storage`
--

INSERT INTO `phone_storage` (`P_STG_ID`, `P_STG_SIZE`, `P_STG_UNIT`) VALUES
(1, 16, 'GB'),
(2, 32, 'GB'),
(3, 64, 'GB'),
(4, 128, 'GB'),
(5, 256, 'GB');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `idSmartPhones` int(16) NOT NULL,
  `productName` varchar(100) NOT NULL,
  `name` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `idSmartPhones`, `productName`, `name`) VALUES
(77, 16, 'iphone X', 'p11.jpg'),
(78, 17, 'iphone X', 'p12.jpg'),
(79, 15, 'iphone X', 'p21.jpg'),
(80, 14, 'iphone X', 'p22.jpg'),
(81, 13, 'iphone X', 'p31.jpg'),
(82, 12, 'iphone X', 'p32.jpg'),
(83, 11, 'iphone X', 'p41.jpg'),
(84, 18, 'iphone X', 'p51.jpg'),
(85, 19, 'iphone X', 'p52.jpg'),
(86, 20, 'iphone XS', 'p61.jpg'),
(87, 21, 'iphone XS', 'p62.jpg'),
(89, 22, 'iphone XS', 'p71.jpg'),
(90, 23, 'iphone XS', 'p72.jpg'),
(91, 24, 'iphone XS', 'p81.jpg'),
(92, 25, 'iphone XS', 'p82.jpg'),
(93, 26, 'iphone XS', 'p92.jpg'),
(94, 27, 'iphone XS', 'p91.jpg'),
(95, 28, 'iphone XS', 'p92.jpg'),
(96, 31, 'iphone XS', 'p101.jpg'),
(97, 15, 'iphone X', 'p102.jpg'),
(98, 16, 'iphone X', 'p103.jpg'),
(99, 17, 'iphone X', 'p111.jpg'),
(100, 18, 'iphone X', 'p112.jpg'),
(101, 19, 'iphone X', 'p113.jpg'),
(102, 20, 'iphone XS', 'p121.jpg'),
(103, 21, 'iphone XS', 'p122.jpg'),
(104, 22, 'iphone XS', 'p131.jpg'),
(134, 22, 'iphone XS', 'p51.jpg'),
(135, 22, 'iphone XS', 'p21.jpg'),
(137, 22, 'iphone XS', 'p31.jpg'),
(138, 22, 'iphone XS', 'p21.jpg'),
(139, 22, 'iphone XS', 'p21.jpg'),
(140, 11, 'iphone X', 'p21.jpg'),
(141, 11, 'iphone X', 'p21.jpg'),
(143, 19, 'iphone X', 'p21.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sp_audit_logon`
--

CREATE TABLE `sp_audit_logon` (
  `userid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logdate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sp_cart`
--

CREATE TABLE `sp_cart` (
  `idCart` int(16) NOT NULL,
  `Quantity` int(5) DEFAULT NULL,
  `idShopper` int(8) DEFAULT NULL,
  `OrderPlaced` int(1) DEFAULT NULL,
  `SubTotal` double DEFAULT NULL,
  `Shipping` double DEFAULT NULL,
  `Tax` double DEFAULT NULL,
  `Total` double DEFAULT NULL,
  `dtCreated` datetime DEFAULT CURRENT_TIMESTAMP,
  `Promo` int(2) DEFAULT NULL,
  `ShipFirstName` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipLastName` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipAddress` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipCity` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipState` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipZipCode` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipPhone` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipFax` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipEmail` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BillFirstName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BillLastName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BillAddress` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BillCity` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BillState` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BillZipCode` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BillPhone` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BillFax` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BillEmail` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dtOrdered` datetime DEFAULT CURRENT_TIMESTAMP,
  `ShipProvince` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipCountry` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BillProvince` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BillCountry` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CardType` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CardNumber` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ExpMonth` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ExpYear` char(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CardName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shipbill` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `ShipFlag` char(1) COLLATE utf8_unicode_ci DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp_cart`
--

INSERT INTO `sp_cart` (`idCart`, `Quantity`, `idShopper`, `OrderPlaced`, `SubTotal`, `Shipping`, `Tax`, `Total`, `dtCreated`, `Promo`, `ShipFirstName`, `ShipLastName`, `ShipAddress`, `ShipCity`, `ShipState`, `ShipZipCode`, `ShipPhone`, `ShipFax`, `ShipEmail`, `BillFirstName`, `BillLastName`, `BillAddress`, `BillCity`, `BillState`, `BillZipCode`, `BillPhone`, `BillFax`, `BillEmail`, `dtOrdered`, `ShipProvince`, `ShipCountry`, `BillProvince`, `BillCountry`, `CardType`, `CardNumber`, `ExpMonth`, `ExpYear`, `CardName`, `shipbill`, `ShipFlag`) VALUES
(1, 1, 100, 0, NULL, NULL, 20, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(9, 2, 100, 1, 1599.98, 5, 72, 1676.98, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(10, 1, 101, 1, 399.99, 5, 18, 422.99, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(11, 3, 101, 1, 2399.97, 5, 108, 2512.97, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(12, 1, 102, 0, NULL, NULL, 40, NULL, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(13, 4, 102, 1, 2799.96, 5, 126, 2930.96, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(14, 1, 103, 1, 799.99, 5, 36, 840.99, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(15, 2, 103, 0, NULL, NULL, 30, NULL, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-02-21 20:16:38', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(16, 1, 100, 1, 399.99, 5, 18, 422.99, '2020-03-20 10:36:11', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-20 10:36:11', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(26, 2, 101, 1, 1599.98, 5, NULL, NULL, '2020-03-20 12:48:45', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-20 12:48:45', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(41, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-03-25 17:55:05', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-25 17:55:05', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(42, NULL, 122, 0, NULL, NULL, NULL, NULL, '2020-03-25 19:03:05', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-25 19:03:05', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(43, NULL, 122, 0, NULL, NULL, NULL, NULL, '2020-03-25 19:03:41', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-25 19:03:41', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(44, 3, 122, 1, 1897, 5, 85.36, 1987.36, '2020-03-27 09:34:16', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-27 09:34:16', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(45, 2, 123, 1, 1398, 5, 62.91, 1465.91, '2020-03-27 13:03:36', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-27 13:03:36', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(46, 3, 123, 1, 1897, 5, 85.36, 1987.36, '2020-03-27 13:06:31', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-27 13:06:31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(47, 2, 123, 1, 1398, 5, 62.91, 1465.91, '2020-03-27 13:08:22', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-27 13:08:22', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(48, 1, 123, 1, 599, 5, 26.96, 630.96, '2020-03-27 13:09:37', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-27 13:09:37', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(49, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-03-28 09:06:23', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-28 09:06:23', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(50, 1, 123, 1, 699, 5, 31.46, 735.46, '2020-03-28 09:11:55', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-28 09:11:55', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(51, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-03-28 09:13:21', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-28 09:13:21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(52, 2, 123, 1, 1398, 5, 62.91, 1465.91, '2020-03-28 09:16:18', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-28 09:16:18', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(53, 1, 123, 1, 699, 5, 31.46, 735.46, '2020-03-28 09:20:16', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-28 09:20:16', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(54, 2, 122, 1, 1298, 5, 58.41, 1361.41, '2020-03-28 09:22:29', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-28 09:22:29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(55, 3, 123, 1, 1897, 5, 85.36, 1987.36, '2020-03-28 09:33:09', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-28 09:33:09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(56, 2, 123, 1, 1398, 5, 62.91, 1465.91, '2020-03-28 10:38:57', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-28 10:38:57', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(57, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-03-30 08:35:38', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-30 08:35:38', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(58, 1, 123, 1, 699, 5, 31.46, 735.46, '2020-03-30 08:37:09', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-30 08:37:09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(59, 1, 123, 1, 699, 5, 31.46, 735.46, '2020-04-09 19:53:23', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-09 19:53:23', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(60, 1, 123, 1, 699, 5, 31.46, 735.46, '2020-04-10 12:29:00', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-10 12:29:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(61, 1, 123, 1, 699, 5, 31.46, 735.46, '2020-04-10 12:56:21', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-10 12:56:21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(62, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-10 13:14:52', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-10 13:14:52', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(63, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-16 17:34:54', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-16 17:34:54', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(64, 1, 123, 1, 699, 5, 31.46, 735.46, '2020-04-16 19:02:34', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-16 19:02:34', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(65, 1, 123, 1, 699.99, 5, 31.5, 736.49, '2020-04-16 19:28:49', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-16 19:28:49', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(66, 1, 123, 1, 799.99, 5, 36, 840.99, '2020-04-16 21:07:00', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-16 21:07:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(67, 3, 123, 1, 2199.97, 5, 99, 2303.97, '2020-04-16 21:08:13', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-16 21:08:13', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(68, 1, 123, 1, 799.99, 5, 36, 840.99, '2020-04-16 21:12:34', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-16 21:12:34', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(69, NULL, 123, 1, NULL, 5, NULL, NULL, '2020-04-16 21:15:07', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-16 21:15:07', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(70, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-16 21:20:53', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-16 21:20:53', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(71, 2, 123, 1, 1499.98, 5, 67.5, 1572.48, '2020-04-18 12:38:13', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-18 12:38:13', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(72, 1, 123, 1, 699.99, 5, 31.5, 736.49, '2020-04-18 12:45:42', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-18 12:45:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(73, 1, 123, 1, 699.99, 5, 31.5, 736.49, '2020-04-20 20:52:39', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 20:52:39', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(74, 2, 123, 1, 1399.98, 5, 63, 1467.98, '2020-04-20 20:53:09', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 20:53:09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(75, 4, 123, 1, 3199.96, 5, 144, 3348.96, '2020-04-20 21:20:22', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 21:20:22', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(76, 1, 123, 1, 699.99, 5, 31.5, 736.49, '2020-04-20 21:21:42', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 21:21:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(77, 1, 123, 1, 699.99, 5, 31.5, 736.49, '2020-04-20 21:23:04', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 21:23:04', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(78, 2, 123, 1, 1399.98, 5, 63, 1467.98, '2020-04-20 23:26:09', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 23:26:09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(79, 1, 123, 1, 799.99, 5, 36, 840.99, '2020-04-20 23:29:57', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 23:29:57', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(80, 1, 123, 1, 699.99, 5, 31.5, 736.49, '2020-04-20 23:33:02', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 23:33:02', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(81, 2, 123, 1, 1399.98, 5, 63, 1467.98, '2020-04-20 23:37:47', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 23:37:47', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(82, 2, 123, 1, 1499.98, 5, 67.5, 1572.48, '2020-04-20 23:54:12', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 23:54:12', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(83, 1, 123, 1, 699.99, 5, 31.5, 736.49, '2020-04-20 23:59:38', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 23:59:38', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(84, 1, 123, 1, 699.99, 5, 31.5, 736.49, '2020-04-21 00:02:04', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-21 00:02:04', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(85, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-21 00:03:20', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-21 00:03:20', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(86, 1, 123, 1, 699.99, 5, 31.5, 736.49, '2020-04-21 12:19:49', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-21 12:19:49', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(87, 2, 123, 1, 1399.98, 5, 63, 1467.98, '2020-04-21 12:48:05', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-21 12:48:05', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(88, 2, 123, 1, 1399.98, 5, 63, 1467.98, '2020-04-21 13:25:58', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-21 13:25:58', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(89, 9, 123, 1, 7099.91, 8, 319.5, 7427.41, '2020-04-21 14:23:04', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-21 14:23:04', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(90, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-21 20:32:45', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-21 20:32:45', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(91, NULL, 123, 1, NULL, 5, NULL, NULL, '2020-04-22 10:42:58', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 10:42:58', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(92, 10, 123, 1, 7399.9, 8, 333, 7740.9, '2020-04-22 12:43:16', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 12:43:16', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(93, 5, 123, 1, 3999.95, 5, 180, 4184.95, '2020-04-22 12:50:57', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 12:50:57', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(94, 2, 123, 1, 1699.98, 5, 76.5, 1781.48, '2020-04-22 13:00:09', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 13:00:09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(95, 14, 123, 1, 10199.8, 15, 458.99, 10673.789999999999, '2020-04-22 13:04:32', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 13:04:32', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(96, 14, 123, 1, 10199.8, 15, 458.99, 10673.789999999999, '2020-04-22 13:18:20', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 13:18:20', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(97, 1, 123, 1, 699.99, 5, 31.5, 736.49, '2020-04-22 13:31:26', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 13:31:26', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(98, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-22 13:32:46', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 13:32:46', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(99, 2, 123, 1, 1499.98, 5, 67.5, 1572.48, '2020-04-22 18:01:42', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 18:01:42', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(100, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-22 18:38:28', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 18:38:28', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(101, 2, 123, 1, 1499.98, 5, 67.5, 1572.48, '2020-04-22 18:44:34', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 18:44:34', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(102, 2, 123, 1, 1499.98, 5, 67.5, 1572.48, '2020-04-22 18:54:11', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 18:54:11', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(103, 3, 123, 1, 2299.97, 5, 103.5, 2408.47, '2020-04-22 19:02:09', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 19:02:09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(104, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-22 20:15:22', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 20:15:22', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(105, 1, 123, 1, 799.99, 5, 36, 840.99, '2020-04-22 20:19:58', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 20:19:58', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(106, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-22 20:24:21', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 20:24:21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(107, 1, 123, 1, 799.99, 5, 36, 840.99, '2020-04-22 20:32:15', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 20:32:15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(108, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-22 20:33:08', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 20:33:08', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(109, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-22 22:16:36', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 22:16:36', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(110, 7, 123, 1, 5499.93, 8, 247.5, 5755.43, '2020-04-22 22:20:16', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 22:20:16', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(111, 2, 123, 1, 1499.98, 5, 67.5, 1572.48, '2020-04-22 22:25:18', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-22 22:25:18', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(112, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-23 09:57:53', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-23 09:57:53', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(113, 7, 122, 1, 5099.93, 8, 229.5, 5337.43, '2020-04-23 09:58:24', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-23 09:58:24', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(114, NULL, 122, 0, NULL, NULL, NULL, NULL, '2020-04-23 10:05:06', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-23 10:05:06', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(115, NULL, 124, 0, NULL, NULL, NULL, NULL, '2020-04-23 10:08:23', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-23 10:08:23', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(116, NULL, 124, 0, NULL, NULL, NULL, NULL, '2020-04-23 10:15:20', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-23 10:15:20', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(117, 2, 123, 1, 1599.98, 5, 72, 1676.98, '2020-04-23 12:48:00', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-23 12:48:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(118, 2, 123, 1, 1499.98, 5, 67.5, 1572.48, '2020-04-23 18:10:14', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-23 18:10:14', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(119, 1, 124, 1, 699.99, 5, 31.5, 736.49, '2020-04-23 18:18:35', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-23 18:18:35', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(120, 13, 124, 1, 9899.87, 15, 445.49, 10360.36, '2020-04-24 11:04:03', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-24 11:04:03', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(121, 1, 123, 1, 699.99, 5, 31.5, 736.49, '2020-04-24 12:14:21', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-24 12:14:21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(122, 1, 123, 1, 799.99, 5, 36, 840.99, '2020-04-24 12:16:49', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-24 12:16:49', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(123, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-24 16:24:31', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-24 16:24:31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(124, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-24 16:31:18', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-24 16:31:18', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(125, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-24 16:31:52', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-24 16:31:52', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(126, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-24 16:33:08', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-24 16:33:08', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(127, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-24 16:34:47', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-24 16:34:47', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(128, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-24 16:40:11', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-24 16:40:11', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(129, 1, 123, 1, 799.99, 5, 36, 840.99, '2020-04-24 16:43:59', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-24 16:43:59', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(130, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-28 20:52:55', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-28 20:52:55', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(131, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-28 20:53:47', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-28 20:53:47', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(132, 1, 123, 1, 799.99, 5, 36, 840.99, '2020-04-28 21:02:29', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-28 21:02:29', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(133, 1, 123, 1, 799.99, 5, 36, 840.99, '2020-04-28 21:09:17', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-28 21:09:17', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(134, NULL, 130, 0, NULL, NULL, NULL, NULL, '2020-04-28 21:14:16', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-28 21:14:16', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(135, 1, 131, 1, 799.99, 5, 36, 840.99, '2020-04-28 21:23:28', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-28 21:23:28', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(136, 1, 132, 1, 799.99, 5, 36, 840.99, '2020-04-28 21:32:31', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-28 21:32:31', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(137, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-04-29 09:23:23', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-29 09:23:23', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(138, 4, 123, 0, 3099.96, 5, 139.5, 3244.46, '2020-04-29 09:41:06', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-29 09:41:06', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(139, 3, 123, 0, 2399.97, 5, 108, 2512.97, '2020-04-29 09:48:16', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-29 09:48:16', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(140, NULL, 133, 0, NULL, NULL, NULL, NULL, '2020-04-29 15:40:19', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-29 15:40:19', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(141, 1, 123, 1, 799.99, 5, 36, 840.99, '2020-04-29 19:22:08', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-29 19:22:08', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(142, 1, 123, 1, 799.99, 5, 36, 840.99, '2020-04-29 19:27:09', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-29 19:27:09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(143, 1, 123, 0, 799.99, 5, 36, 840.99, '2020-04-29 19:45:36', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-29 19:45:36', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(144, 8, 123, 1, 6399.92, 8, 288, 6695.92, '2020-05-01 19:21:52', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-05-01 19:21:52', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(145, 4, 123, 0, 3199.96, 5, 144, 3348.96, '2020-05-01 19:23:34', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-05-01 19:23:34', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(146, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-05-01 19:24:55', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-05-01 19:24:55', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N'),
(147, NULL, 123, 0, NULL, NULL, NULL, NULL, '2020-05-02 09:15:25', NULL, NULL, NULL, NULL, NULL, 'VA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-05-02 09:15:25', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N');

--
-- Triggers `sp_cart`
--
DELIMITER $$
CREATE TRIGGER `product_inventory_trgs` AFTER UPDATE ON `sp_cart` FOR EACH ROW BEGIN
declare lv_idcart int(8); 
 declare lv_firstname varchar(30);
 declare lv_lastname VARCHAR(30);
  declare lv_address varchar(100);
 declare lv_dtcreated date;
  declare lv_qty int(5);
 declare lv_productname VARCHAR(50);
  declare lv_description varchar(80);
 declare lv_phonetype VARCHAR(20);
 declare lv_storageGB int(5);
  declare lv_color varchar(20);
 declare lv_grade VARCHAR(20);
declare lv_change_number DOUBLE; 
 declare lv_finished int(2);
 declare lv_idSmartPhones VARCHAR(16);
 declare lv_id_phoneoption int(11);
 declare lv_quantity int(8);
 declare lv_qyts int(8);
DECLARE cursor1 CURSOR FOR 
 SELECT idSmartPhones, quantity, P_OPT_ID 
 FROM sp_cartitem
 WHERE idCart = NEW.idCart;
 
 DECLARE CONTINUE HANDLER 
        FOR NOT FOUND SET lv_finished = 1;
  
 OPEN cursor1;
 getRedcord: LOOP
 FETCH cursor1 INTO lv_idSmartPhones, lv_quantity,lv_id_phoneoption;
 IF lv_finished = 1 THEN 
     LEAVE getRedcord;
 END IF;
 if NEW.OrderPlaced = 1 then
 UPDATE sp_phones 
 SET stock = stock - lv_quantity 
 WHERE idSmartPhones = lv_idSmartPhones; 
  UPDATE phone_options 
 SET P_QUANTITY = P_QUANTITY - lv_quantity 
 WHERE P_OPT_ID = lv_id_phoneoption;
end if;
BEGIN

DECLARE cursor2 CURSOR FOR 
SELECT c.idcart, firstname, lastname, address, dtcreated, ci.quantity, productname, description, phonetype,ci.storageGB, ci.color, grade
FROM sp_shopper s, sp_cart c, sp_cartitem ci, sp_phones p
WHERE s.idshopper = c.idshopper and c.idcart = ci.idcart and ci.idsmartphones = p.idsmartphones and ci.idCart = NEW.idCart AND NEW.OrderPlaced = 1;

OPEN cursor2;
 getRedcord1: LOOP
 FETCH cursor2 INTO lv_idcart, lv_firstname,lv_lastname,lv_address,lv_dtcreated,lv_qty,lv_productname,lv_description,lv_phonetype,lv_storageGB, lv_color, lv_grade;
 IF lv_finished = 1 THEN 
     LEAVE getRedcord1;
 END IF;
 if NEW.OrderPlaced = 1 then
insert into SP_phone_onlinesell_record(idonlineSaleHistory,idBasket,CustomerFName,customerLName,address,dtcreated,qtys,
productname,description,phonetype,storageGB,color,grade,currentdate,actionTaken)
values(null, lv_idcart, lv_firstname, lv_lastname,lv_address,lv_dtcreated,lv_qty,
lv_productname,lv_description,lv_phonetype,lv_storageGB,lv_color,lv_grade,SYSDATE(), 'S-SOLD');
END IF;
 END LOOP getRedcord1;
 CLOSE cursor2; 

END;
 END LOOP getRedcord;
 CLOSE cursor1; 
 
 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `sp_cartitem`
--

CREATE TABLE `sp_cartitem` (
  `idCartItem` int(8) NOT NULL,
  `P_OPT_ID` int(11) NOT NULL,
  `idSmartPhones` int(8) DEFAULT NULL,
  `color` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `storageGB` int(5) NOT NULL,
  `Price` double DEFAULT NULL,
  `Quantity` int(5) DEFAULT NULL,
  `idCart` int(8) DEFAULT NULL,
  `option1` int(2) DEFAULT NULL,
  `option2` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp_cartitem`
--

INSERT INTO `sp_cartitem` (`idCartItem`, `P_OPT_ID`, `idSmartPhones`, `color`, `storageGB`, `Price`, `Quantity`, `idCart`, `option1`, `option2`) VALUES
(133, 2, 21, 'black', 64, 699.99, 3, 99, NULL, NULL),
(134, 2, 24, 'black', 128, 799.99, 5, 99, NULL, NULL),
(142, 2, 20, 'black', 64, 799.99, 4, 101, NULL, NULL),
(143, 2, 21, 'black', 64, 699.99, 3, 101, NULL, NULL),
(144, 2, 20, 'black', 64, 799.99, 4, 102, NULL, NULL),
(145, 2, 21, 'black', 64, 699.99, 3, 102, NULL, NULL),
(146, 2, 20, 'black', 64, 799.99, 4, 103, NULL, NULL),
(147, 2, 21, 'black', 64, 699.99, 3, 103, NULL, NULL),
(148, 2, 20, 'black', 64, 799.99, 4, 104, NULL, NULL),
(150, 2, 20, 'black', 64, 799.99, 4, 105, NULL, NULL),
(151, 2, 20, 'black', 64, 799.99, 4, 107, NULL, NULL),
(152, 2, 20, 'black', 64, 799.99, 4, 110, NULL, NULL),
(153, 2, 21, 'black', 64, 699.99, 3, 110, NULL, NULL),
(154, 2, 24, 'black', 128, 799.99, 5, 110, NULL, NULL),
(155, 2, 20, 'black', 64, 799.99, 4, 111, NULL, NULL),
(156, 2, 21, 'black', 64, 699.99, 3, 111, NULL, NULL),
(157, 2, 20, 'black', 64, 799.99, 4, 113, NULL, NULL),
(158, 2, 21, 'black', 64, 699.99, 3, 113, NULL, NULL),
(159, 2, 20, 'black', 64, 799.99, 4, 117, NULL, NULL),
(160, 2, 20, 'black', 64, 799.99, 4, 118, NULL, NULL),
(161, 2, 21, 'black', 64, 699.99, 3, 118, NULL, NULL),
(162, 2, 25, 'black', 128, 699.99, 1, 119, NULL, NULL),
(187, 2, 25, 'black', 128, 699.99, 1, 120, NULL, NULL),
(188, 2, 23, 'black', 128, 899.99, 1, 120, NULL, NULL),
(189, 2, 22, 'black', 64, 599.99, 1, 120, NULL, NULL),
(190, 2, 21, 'black', 64, 699.99, 3, 120, NULL, NULL),
(191, 2, 20, 'black', 64, 799.99, 4, 120, NULL, NULL),
(192, 2, 28, 'black', 256, 799.99, 2, 120, NULL, NULL),
(193, 2, 13, 'black', 64, 499.99, 1, 120, NULL, NULL),
(194, 2, 15, 'black', 128, 699.99, 1, 120, NULL, NULL),
(195, 2, 16, 'black', 128, 599.99, 1, 120, NULL, NULL),
(196, 2, 17, 'black', 256, 899.99, 1, 120, NULL, NULL),
(197, 2, 24, 'black', 128, 799.99, 1, 120, NULL, NULL),
(198, 2, 26, 'black', 256, 999.99, 1, 120, NULL, NULL),
(199, 2, 27, 'black', 256, 899.99, 1, 120, NULL, NULL),
(200, 2, 25, 'black', 128, 699.99, 1, 121, NULL, NULL),
(202, 2, 20, 'black', 64, 799.99, 4, 122, NULL, NULL),
(203, 2, 20, 'black', 64, 799.99, 4, 123, NULL, NULL),
(204, 2, 21, 'black', 64, 699.99, 3, 125, NULL, NULL),
(206, 2, 20, 'black', 64, 799.99, 4, 128, NULL, NULL),
(207, 2, 20, 'black', 64, 799.99, 4, 129, NULL, NULL),
(210, 2, 20, 'black', 64, 799.99, 4, 132, NULL, NULL),
(211, 2, 20, 'black', 64, 799.99, 4, 133, NULL, NULL),
(212, 2, 20, 'black', 64, 799.99, 4, 134, NULL, NULL),
(213, 2, 20, 'black', 64, 799.99, 4, 135, NULL, NULL),
(214, 2, 20, 'black', 64, 799.99, 4, 136, NULL, NULL),
(217, 2, 20, 'black', 64, 799.99, 4, 137, NULL, NULL),
(218, 2, 21, 'black', 64, 699.99, 3, 137, NULL, NULL),
(219, 2, 20, 'black', 64, 799.99, 4, 138, NULL, NULL),
(220, 2, 15, 'black', 128, 699.99, 1, 138, NULL, NULL),
(223, 2, 20, 'black', 64, 799.99, 4, 139, NULL, NULL),
(224, 2, 28, 'black', 256, 799.99, 2, 139, NULL, NULL),
(225, 2, 20, 'black', 64, 799.99, 4, 140, NULL, NULL),
(226, 2, 20, 'black', 64, 799.99, 4, 141, NULL, NULL),
(227, 2, 20, 'black', 64, 799.99, 4, 142, NULL, NULL),
(228, 2, 20, 'black', 64, 799.99, 4, 143, NULL, NULL),
(229, 2, 20, 'black', 64, 799.99, 4, 144, NULL, NULL),
(230, 2, 20, 'black', 64, 799.99, 4, 145, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sp_cartstatus`
--

CREATE TABLE `sp_cartstatus` (
  `idStatus` int(8) NOT NULL,
  `idCart` int(8) DEFAULT NULL,
  `idStage` int(1) DEFAULT NULL,
  `dtStage` date DEFAULT NULL,
  `Notes` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shipper` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShippingNum` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sp_companycustomer`
--

CREATE TABLE `sp_companycustomer` (
  `idCustomer` int(8) NOT NULL,
  `CCustomerName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CCustomerAddress` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CCustomercity` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CCustomerState` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CCustomerZip` char(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CCcustomerPhone` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sp_department`
--

CREATE TABLE `sp_department` (
  `idDepartment` int(3) NOT NULL,
  `DeptName` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `DeptDesc` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `DeptImage` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp_department`
--

INSERT INTO `sp_department` (`idDepartment`, `DeptName`, `DeptDesc`, `DeptImage`) VALUES
(1, 'Whole Sale', 'sells all type of unlocked pho', 'office.png'),
(2, 'Retail', 'instore sells all type of unlo', 'store.png');

-- --------------------------------------------------------

--
-- Table structure for table `sp_expense`
--

CREATE TABLE `sp_expense` (
  `idexpense` int(8) NOT NULL,
  `expensename` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `totalexpense` double DEFAULT NULL,
  `currentdate` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp_expense`
--

INSERT INTO `sp_expense` (`idexpense`, `expensename`, `description`, `totalexpense`, `currentdate`) VALUES
(1, 'ticket to texas', 'flight to texas to buy phone', 2000, '2020-03-07 00:05:03'),
(2, 'ticket to texas', 'flight to texas to buy phone', 2000, '2020-03-07 00:36:51'),
(3, 'ticket to texas', 'flight to texas to buy phone', 2000, '2020-03-07 10:44:01'),
(4, 'ticket to texas', 'flight to texas to buy phone', 2000, '2020-03-07 11:09:19'),
(5, 'travel', '43', 2222, '2020-04-10 12:50:20'),
(6, 'travel', 'buy inventory', 2000, '2020-04-22 18:43:19'),
(7, 'travel', 'buy inventory', 2000, '2020-04-22 18:53:07'),
(8, 'travel', 'buy inventory', 2000, '2020-04-22 20:19:12'),
(9, 'travel', 'buy inventory', 2000, '2020-04-22 20:31:37'),
(10, 'travel', 'buy inventory', 2000, '2020-04-24 16:23:11'),
(11, 'travel', 'buy inventory', 2000, '2020-04-24 16:29:41'),
(12, 'travel', 'buy inventory', 2000, '2020-04-24 16:38:48'),
(13, 'travel', 'buy inventory', 2000, '2020-04-24 16:42:45'),
(14, 'travel', 'buy inventory', 2000, '2020-04-28 21:05:30'),
(15, 'travel', 'buy inventory', 2000, '2020-04-28 21:26:31'),
(16, 'travel', 'buy inventory', 2000, '2020-04-28 21:35:02'),
(17, 'travel', 'buy inventory', 2000, '2020-04-29 19:24:32');

-- --------------------------------------------------------

--
-- Table structure for table `sp_invoiceitems`
--

CREATE TABLE `sp_invoiceitems` (
  `idInvoice` int(8) NOT NULL,
  `iditems` int(8) NOT NULL,
  `invoiceQuantity` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sp_invoicephone`
--

CREATE TABLE `sp_invoicephone` (
  `idInvoice` int(8) NOT NULL,
  `idCustomer` int(8) DEFAULT NULL,
  `InvoiceDate` date DEFAULT NULL,
  `invoiceTotal` double DEFAULT NULL,
  `invoiceQuantity` int(5) DEFAULT NULL,
  `PayStatus` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sp_items`
--

CREATE TABLE `sp_items` (
  `iditems` int(8) NOT NULL,
  `IMEI` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PhoneName` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Description` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PhoneType` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sp_online_orderprocess_record`
--

CREATE TABLE `sp_online_orderprocess_record` (
  `idonlineProcess` int(8) NOT NULL,
  `idBasket` int(8) DEFAULT NULL,
  `CustomerFName` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customerLName` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dtcreated` date DEFAULT NULL,
  `quantities` int(6) DEFAULT NULL,
  `productname` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonetype` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `storageGB` int(5) NOT NULL,
  `color` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `grade` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currentdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `actionTaken` char(1) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sp_phones`
--

CREATE TABLE `sp_phones` (
  `idSmartPhones` int(8) NOT NULL,
  `sku` int(8) NOT NULL,
  `ProductName` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Description` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PhoneType` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `storageGB` int(5) NOT NULL,
  `grade` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `ProductImage` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `stock` int(8) NOT NULL,
  `SaleStart` date DEFAULT NULL,
  `SaleEnd` date DEFAULT NULL,
  `SalePrice` double DEFAULT NULL,
  `Active` int(1) DEFAULT NULL,
  `Featured` int(1) DEFAULT NULL,
  `FeatureStart` date DEFAULT NULL,
  `FeatureEnd` date DEFAULT NULL,
  `Type` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idDepartment` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp_phones`
--

INSERT INTO `sp_phones` (`idSmartPhones`, `sku`, `ProductName`, `Description`, `PhoneType`, `color`, `storageGB`, `grade`, `ProductImage`, `Price`, `stock`, `SaleStart`, `SaleEnd`, `SalePrice`, `Active`, `Featured`, `FeatureStart`, `FeatureEnd`, `Type`, `idDepartment`) VALUES
(11, 1, 'iphone X', 'iphone X, 64 GB', 'iphoneX', '', 64, 'A', 'iphoneXS.png', 699.99, 100, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(12, 1, 'iphone X', 'iphone X, 64 GB ', 'iphoneX', '', 64, 'B', 'iphoneXS.png', 599.99, 100, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(13, 1, 'iphone X', 'iphone X, 64 GB ', 'iphoneX', '', 64, 'C', 'iphoneXS.png', 499.99, 100, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(14, 1, 'iphone X', 'iphone X, 128 GB', 'iphoneX', '', 128, 'A', 'iphoneXS.png', 799.99, 100, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(15, 1, 'iphone X', 'iphone X, 128 GB', 'iphoneX', '', 128, 'B', 'iphoneXS.png', 699.99, 100, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(16, 1, 'iphone X', 'iphone X, 128 GB', 'iphoneX', '', 128, 'C', 'iphoneXS.png', 599.99, 98, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(17, 1, 'iphone X', 'iphone X, 256 GB ', 'iphoneX', '', 256, 'A', 'iphoneXS.png', 899.99, 100, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(18, 1, 'iphone X', 'iphone X, 256 GB ', 'iphoneX', '', 256, 'B', 'iphoneXS.png', 799.99, 100, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(19, 1, 'iphone X', 'iphone X, 256 GB', 'iphoneX', '', 256, 'C', 'iphoneXS.png', 699.99, 94, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(20, 1, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', '', 64, 'A', 'iphoneXS.png', 799.99, 100, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(21, 1, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', '', 64, 'B', 'iphoneXS.png', 699.99, 4, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(22, 1, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', '', 64, 'C', 'iphoneXS.png', 599.99, 10, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(23, 1, 'iphone XS', 'iphone XS, 128 GB ', 'iphoneXS', '', 128, 'A', 'iphoneXS.png', 899.99, 10, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(24, 1, 'iphone XS', 'iphone XS, 128 GB ', 'iphoneXS', '', 128, 'B', 'iphoneXS.png', 799.99, 10, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(25, 1, 'iphone XS', 'iphone XS, 128 GB ', 'iphoneXS', '', 128, 'C', 'iphoneXS.png', 699.99, 96, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(26, 1, 'iphone XS', 'iphone XS, 256 GB ', 'iphoneXS', '', 256, 'A', 'iphoneXS.png', 999.99, 100, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(27, 1, 'iphone XS', 'iphone XS, 256 GB ', 'iphoneXS', '', 256, 'B', 'iphoneXS.png', 899.99, 100, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(28, 1, 'iphone XS', 'iphone XS, 256 GB ', 'iphoneXS', '', 256, 'C', 'iphoneXS.png', 799.99, 2, NULL, NULL, NULL, 1, NULL, NULL, NULL, 'S', 1),
(31, 0, 'Iphone 12', 'Iphone 12 Midnight Green, 64 GB', 'iphone12', '', 64, 'A', NULL, 799.98, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL);

--
-- Triggers `sp_phones`
--
DELIMITER $$
CREATE TRIGGER `update_stock_logs_trigs` AFTER UPDATE ON `sp_phones` FOR EACH ROW BEGIN
INSERT INTO SP_updatePhoneStock(idforphone,PhoneName,Description,PhoneType,storageGB,grade,Price,PhoneSku,oldstock,dateChanged,type) 
VALUES (null, OLD.ProductName, OLD.Description, OLD.PhoneType, OLD.storageGB, OLD.grade, OLD.Price, old.idsmartphones, OLD.stock, SYSDATE(), 'UPDATE');
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `sp_phonesoption`
--

CREATE TABLE `sp_phonesoption` (
  `idSmartPhonesoption` int(3) NOT NULL,
  `idoption` int(2) DEFAULT NULL,
  `idSmartPhones` int(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sp_phonesoptioncategory`
--

CREATE TABLE `sp_phonesoptioncategory` (
  `idOptionCategory` int(5) NOT NULL,
  `CategoryName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sp_phonesoptiondetail`
--

CREATE TABLE `sp_phonesoptiondetail` (
  `idoption` int(2) NOT NULL,
  `OptionName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `idOptionCategory` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sp_phonespos`
--

CREATE TABLE `sp_phonespos` (
  `idphonepos` int(16) NOT NULL,
  `IMEI` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `PhoneName` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `P_OPT_ID` int(8) DEFAULT NULL,
  `PhoneType` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `storageGB` int(5) NOT NULL,
  `color` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `grade` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ProductImage` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `SaleStart` date DEFAULT NULL,
  `SaleEnd` date DEFAULT NULL,
  `SalePrice` double DEFAULT NULL,
  `Active` int(1) DEFAULT NULL,
  `idCustomer` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FeatureStart` date DEFAULT NULL,
  `FeatureEnd` date DEFAULT NULL,
  `Type` char(1) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp_phonespos`
--

INSERT INTO `sp_phonespos` (`idphonepos`, `IMEI`, `PhoneName`, `description`, `P_OPT_ID`, `PhoneType`, `storageGB`, `color`, `grade`, `ProductImage`, `Price`, `SaleStart`, `SaleEnd`, `SalePrice`, `Active`, `idCustomer`, `FeatureStart`, `FeatureEnd`, `Type`) VALUES
(39, '1234567888', 'IPHONE XS', '', NULL, 'iphoneXS', 64, 'black', 'A', NULL, 799, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(40, '1234567891', 'IPHONE XS', '', NULL, 'iphoneXS', 64, 'black', 'A', NULL, 799, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(42, '12345678972', 'IPHONE XS', '', NULL, 'iphoneXS', 64, 'black', 'A', NULL, 799, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(43, '12345678555', 'IPHONE XS', '', NULL, 'iphoneXS', 64, 'black', 'A', NULL, 799, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(44, '1234567890', 'IPHONE XS', '', NULL, 'iphoneXS', 64, 'black', 'A', NULL, 799, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Triggers `sp_phonespos`
--
DELIMITER $$
CREATE TRIGGER `ADD_NEW_INVENTORY` AFTER INSERT ON `sp_phonespos` FOR EACH ROW BEGIN
	IF NEW.PhoneType IS NOT NULL THEN 
	update phone_options
    SET p_quantity = p_quantity + 1
    WHERE P_OPT_ID = NEW.P_OPT_ID ;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `phoneSale_history_trigs` AFTER DELETE ON `sp_phonespos` FOR EACH ROW BEGIN
declare lv_idonlineProcess int(8);
	declare lv_finished int(2);
    declare lv_quantity int(6);
    DECLARE cursor1 CURSOR FOR 
 SELECT quantities, idonlineProcess
 FROM SP_Online_orderprocess_record
 WHERE idonlineProcess = idonlineProcess;
  DECLARE CONTINUE HANDLER 
        FOR NOT FOUND SET lv_finished = 1;
  OPEN cursor1;
 
  FETCH cursor1 INTO lv_quantity, lv_idonlineProcess;
 
     
 

 IF (lv_quantity > 1) then
 UPDATE SP_Online_orderprocess_record 
 SET quantities = quantities - 1
 WHERE idonlineProcess = lv_idonlineProcess; 
 
 INSERT INTO sp_phone_sales_history (idSaleHistory, idSmartPhones, ProductName, Description, PhoneType, storageGB, sphonecolor, grade,Price, currentdate,datesold, actionTaken)
	VALUES(null,OLD.IMEI,OLD.PhoneName,OLD.Description,OLD.PhoneType, old.storageGB, old.color, OLD.grade, OLD.Price, SYSDATE(),SYSDATE(), 'U-Sold');
 ELSEIF (lv_quantity = 1) THEN
 DELETE FROM SP_Online_orderprocess_record 
    WHERE OLD.PhoneType = Phonetype and OLD.color = color and old.grade = grade and OLD.storageGB = storageGB;
    
    INSERT INTO sp_phone_sales_history (idSaleHistory, idSmartPhones, ProductName, Description, PhoneType, storageGB,sphonecolor, grade,Price, currentdate,datesold, actionTaken)
	VALUES(null,OLD.IMEI,OLD.PhoneName,OLD.Description,OLD.PhoneType, old. storageGB, old.color, OLD.grade, OLD.Price,SYSDATE(),SYSDATE(), 'U-Sold');
end if;
 
 CLOSE cursor1;
 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `sp_phones_request`
--

CREATE TABLE `sp_phones_request` (
  `idRequest` int(4) NOT NULL,
  `idSmartPhones` int(8) DEFAULT NULL,
  `dtrequest` datetime DEFAULT CURRENT_TIMESTAMP,
  `dtrecd` date DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `qty` int(5) DEFAULT NULL,
  `idvender` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sp_phonetype`
--

CREATE TABLE `sp_phonetype` (
  `idphonetype` int(8) NOT NULL,
  `phonetype` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `PhonetypeName` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp_phonetype`
--

INSERT INTO `sp_phonetype` (`idphonetype`, `phonetype`, `PhonetypeName`) VALUES
(1, 'iphone11pro', 'Iphone 11 Pro'),
(2, 'iphone11', 'Iphone 11 '),
(5, 'iphoneX', 'Iphone X'),
(6, 'iphoneXS', 'Iphone XS'),
(7, 'iphone8plus', 'Iphone 8 Plus'),
(8, 'iphone8', 'IPhone 8'),
(9, 'iphone7plus', 'Iphone 7 Plus'),
(10, 'iphone7', 'Iphone 7'),
(11, 'iphone6s', 'Iphone 6s'),
(13, 'iphone12', 'Iphone 12'),
(14, 'nokia', 'nokia 8898'),
(25, 'samsung10', 'galaxy s4'),
(26, 'samsung12', 'galaxy s4'),
(27, 'samsung12', 'galaxy s4'),
(28, 'samsung12', 'galaxy s4');

-- --------------------------------------------------------

--
-- Table structure for table `sp_phone_onlinesell_record`
--

CREATE TABLE `sp_phone_onlinesell_record` (
  `idonlineSaleHistory` int(8) NOT NULL,
  `idBasket` int(8) DEFAULT NULL,
  `CustomerFName` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customerLName` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dtcreated` date DEFAULT NULL,
  `qtys` int(6) NOT NULL,
  `productname` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonetype` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `storageGB` int(5) NOT NULL,
  `color` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `grade` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currentdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `actionTaken` char(1) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Triggers `sp_phone_onlinesell_record`
--
DELIMITER $$
CREATE TRIGGER `addTo_process_order_TRg` AFTER DELETE ON `sp_phone_onlinesell_record` FOR EACH ROW BEGIN
	

insert into SP_Online_orderprocess_record(idonlineProcess,idBasket,CustomerFName,customerLName,address,dtcreated,quantities,
productname,description,phonetype,storageGB,color,grade,currentdate,actionTaken)
values(null, OLD.idBasket, OLD.CustomerFName, OLD.customerLName,OLD.address,OLD.dtcreated,OLD.qtys,
OLD.productname,OLD.description,OLD.phonetype,OLD.storageGB,OLD.color,OLD.grade,SYSDATE(), 'S-SOLD');


END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `sp_phone_sales_history`
--

CREATE TABLE `sp_phone_sales_history` (
  `idSaleHistory` int(8) NOT NULL,
  `idSmartPhones` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ProductName` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Description` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PhoneType` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `storageGB` int(6) NOT NULL,
  `sphonecolor` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `grade` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `currentdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `datesold` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actionTaken` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp_phone_sales_history`
--

INSERT INTO `sp_phone_sales_history` (`idSaleHistory`, `idSmartPhones`, `ProductName`, `Description`, `PhoneType`, `storageGB`, `sphonecolor`, `grade`, `Price`, `currentdate`, `datesold`, `actionTaken`) VALUES
(1, '54353454353', 'iphone 6', '', 'iphone6s', 64, 'black', 'A', 699.98, '2020-04-22 18:48:06', '2020-04-22 18:48:06', 'U-Sold'),
(2, '123456789871', 'Iphone X', '', 'iphoneX', 64, 'black', 'A', 699.98, '2020-04-22 18:48:09', '2020-04-22 18:48:09', 'U-Sold'),
(3, '123456789881', 'Iphone 12', '', 'iphone12', 64, 'black', 'A', 799.98, '2020-04-22 18:48:11', '2020-04-22 18:48:11', 'U-Sold'),
(4, '123456789875', 'Iphone XS', '', 'iphoneXS', 64, 'black', 'A', 799.98, '2020-04-22 18:48:13', '2020-04-22 18:48:13', 'U-Sold'),
(5, '123456789872', 'Iphone 6', '', 'iphoneX', 64, 'black', 'A', 699.98, '2020-04-22 18:48:16', '2020-04-22 18:48:16', 'U-Sold'),
(6, '1234567890', 'IPHONE XS', '', 'iphoneXS', 64, 'black', 'A', 799, '2020-04-22 18:55:21', '2020-04-22 18:55:21', 'U-Sold'),
(7, '1234567893', 'IPHONE XS', '', 'iphoneXS', 64, 'black', 'B', 699, '2020-04-22 18:55:44', '2020-04-22 18:55:44', 'U-Sold'),
(8, '1234567890', 'IPHONE XS', '', 'iphoneXS', 64, 'black', 'A', 799, '2020-04-22 19:03:03', '2020-04-22 19:03:03', 'U-Sold'),
(9, '1234567891', 'IPHONE XS', '', 'iphoneXS', 64, 'black', 'A', 799, '2020-04-22 19:03:34', '2020-04-22 19:03:34', 'U-Sold'),
(10, '1234567894', 'IPHONE XS', '', 'iphoneXS', 64, 'black', 'B', 699, '2020-04-22 19:03:48', '2020-04-22 19:03:48', 'U-Sold'),
(11, '1234567897', 'IPHONE XS', '', 'iphoneXS', 64, 'black', 'A', 799, '2020-04-22 20:21:09', '2020-04-22 20:21:09', 'U-Sold'),
(12, '1234567890', 'IPHONE XS', '', 'iphoneXS', 64, 'black', 'A', 799, '2020-04-22 20:33:57', '2020-04-22 20:33:57', 'U-Sold'),
(13, '1234567890', 'IPHONE XS', '', 'iphoneXS', 64, 'black', 'A', 799, '2020-04-24 16:45:57', '2020-04-24 16:45:57', 'U-Sold'),
(15, '1234567892', 'IPHONE XS', '', 'iphoneXS', 64, 'black', 'A', 799, '2020-04-28 21:25:51', '2020-04-28 21:25:51', 'U-Sold'),
(16, '123456789000', 'IPHONE XS', '', 'iphoneXS', 64, 'black', 'A', 799, '2020-04-28 21:34:14', '2020-04-28 21:34:14', 'U-Sold'),
(17, '1234567895', 'IPHONE XS', '', 'iphoneXS', 64, 'black', 'A', 799, '2020-04-29 19:23:19', '2020-04-29 19:23:19', 'U-Sold');

-- --------------------------------------------------------

--
-- Table structure for table `sp_promolist`
--

CREATE TABLE `sp_promolist` (
  `idshopper` int(8) NOT NULL,
  `month` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `year` char(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `promo_flag` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Used` char(1) COLLATE utf8_unicode_ci DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sp_purchasevendor`
--

CREATE TABLE `sp_purchasevendor` (
  `idpurchase` int(8) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `invoice` int(20) NOT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(8) DEFAULT NULL,
  `totaldue` double DEFAULT NULL,
  `status` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currentdate` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp_purchasevendor`
--

INSERT INTO `sp_purchasevendor` (`idpurchase`, `name`, `invoice`, `description`, `quantity`, `totaldue`, `status`, `currentdate`) VALUES
(10, 'primary one inc', 1234556789, 'iphone products', 100, 10000, 'paid', '2020-04-28 21:05:17'),
(11, 'primary one inc', 1234556789, 'iphone product', 100, 10000, 'paid', '2020-04-28 21:26:23'),
(12, 'primary one inc', 2147483647, 'iphone products', 90, 10000, 'paid', '2020-04-28 21:34:52'),
(13, 'primary one inc', 1234556789, 'iphone products', 90, 10000, 'paid', '2020-04-29 19:24:21');

-- --------------------------------------------------------

--
-- Table structure for table `sp_shipping`
--

CREATE TABLE `sp_shipping` (
  `idRange` int(5) NOT NULL,
  `Low` int(3) DEFAULT NULL,
  `High` int(3) DEFAULT NULL,
  `Fee` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp_shipping`
--

INSERT INTO `sp_shipping` (`idRange`, `Low`, `High`, `Fee`) VALUES
(1, 1, 1, 5),
(2, 6, 20, 10),
(3, 21, 999, 15);

--
-- Triggers `sp_shipping`
--
DELIMITER $$
CREATE TRIGGER `online_sale_history_trig` AFTER UPDATE ON `sp_shipping` FOR EACH ROW BEGIN
declare lv_finished int(2);
declare lv_idcart int(8); 
 declare lv_firstname varchar(30);
 declare lv_lastname VARCHAR(30);
  declare lv_address varchar(100);
 declare lv_dtcreated date;
  declare lv_qty int(5);
 declare lv_productname VARCHAR(50);
  declare lv_description varchar(80);
 declare lv_phonetype VARCHAR(20);
  declare lv_color varchar(20);
 declare lv_grade VARCHAR(20);
 
DECLARE cursor1 CURSOR FOR 

SELECT c.idcart, firstname, lastname, address, dtcreated, ci.quantity, productname, description, phonetype, color, grade
FROM sp_shopper s, sp_cart c, sp_cartitem ci, sp_phones p
WHERE s.idshopper = c.idshopper and c.idcart = ci.idcart and ci.idsmartphones = p.idsmartphones and c.orderplaced = 1;
 
 DECLARE CONTINUE HANDLER 
 FOR NOT FOUND SET lv_finished = 1;
 OPEN cursor1;
 getRedcord: LOOP
 FETCH cursor1 INTO lv_idcart, lv_firstname,lv_lastname,lv_address,lv_dtcreated,lv_qty,lv_productname,lv_description,lv_phonetype, lv_color, lv_grade;
 IF lv_finished = 1 THEN 
     LEAVE getRedcord;
 END IF;
 if NEW.high = 1 then
insert into SP_phone_onlinesell_record(idonlineSaleHistory,idBasket,CustomerFName,customerLName,address,dtcreated,qtys,
productname,description,phonetype,color,grade,currentdate,actionTaken)
values(null, lv_idcart, lv_firstname, lv_lastname,lv_address,lv_dtcreated,lv_qty,
lv_productname,lv_description,lv_phonetype,lv_color,lv_grade,SYSDATE(), 'S-SOLD');
end if;
 END LOOP getRedcord;
 CLOSE cursor1; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `sp_shopper`
--

CREATE TABLE `sp_shopper` (
  `idShopper` int(8) NOT NULL,
  `FirstName` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LastName` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Address` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `City` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `State` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ZipCode` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Phone` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Fax` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UserName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Password` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Cookie` int(4) DEFAULT '0',
  `dtEntered` datetime DEFAULT CURRENT_TIMESTAMP,
  `Province` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Country` varchar(35) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp_shopper`
--

INSERT INTO `sp_shopper` (`idShopper`, `FirstName`, `LastName`, `Address`, `City`, `State`, `ZipCode`, `Phone`, `Fax`, `Email`, `UserName`, `Password`, `Cookie`, `dtEntered`, `Province`, `Country`) VALUES
(100, 'Tim', 'Tran', '1400 University St.', 'Fairfax', 'VA', '22033', '7031234567', NULL, 'smartphonedepot@gmail.com', 'user1', '123456', 1, '0000-00-00 00:00:00', NULL, 'USA'),
(101, 'Alana', 'Young', '1401 University St.', 'Fairfax', 'VA', '22033', '7031234576', NULL, 'smartphonedepot@gmail.com', 'user2', '123456', 1, '0000-00-00 00:00:00', NULL, 'USA'),
(102, 'Heiwad', '', '1402 University St.', 'Fairfax', 'VA', '22033', '7031234576', NULL, 'smartphonedepot@gmail.com', 'user3', '12345678', 1, '0000-00-00 00:00:00', NULL, 'USA'),
(103, 'Harman', 'Waraich', '1403 University St.', 'Fairfax', 'VA', '22033', '7031234578', NULL, 'smartphonedepot@gmail.com', 'user4', '123456', 1, '0000-00-00 00:00:00', NULL, 'USA'),
(118, 'Enujin', 'Song', '4400 university', 'fairfax', 'VA', '22033', NULL, NULL, NULL, 'user5', '$2y$10$.bpgYrPCXGNepL.aPGHAMeM5cPS/xWL7MtN/9T12gnXaLfqxdSeia', 0, '2020-01-13 00:11:18', NULL, NULL),
(120, 'arian', 'arabshahi', '123 test street', 'sterling', 'VA', '20166', NULL, NULL, NULL, 'arian.arabshahi123', '$2y$10$yh44X2JePJfRp/FeBl.IM.TfSDx/uPAyrCSSbbLS0qx7/lvhjdHsW', 0, '2020-01-17 19:31:36', NULL, NULL),
(121, 'tim', 'tran', '1412 main st', 'fairfax', 'VA', '23423', NULL, NULL, NULL, 'tim', '$2y$10$Q/H5FgwzcWwWaQY7zoYgF.f4g3D8sLz10QpRFymh66lTryh/86guC', 0, '2020-02-01 10:19:27', NULL, NULL),
(122, 'tim', 'tran', '1412 main st', 'fairfax', 'VA', '54321', NULL, NULL, NULL, 'user9', '$2y$10$fV8aUM.vwq7uCaQWfvukO.I029HCbD5H5SEoJRdRMgUes/hnCkf1a', 0, '2020-02-22 13:36:53', NULL, NULL),
(123, 'Timothy', 'Tran', '1706 university', 'fairfax', 'VA', '22034', NULL, NULL, NULL, 'timtran', '$2y$10$gdmxQ2F.7G9lHYO1EH.zp.3MOScSvxOW/BQX7cgv8DwsHO88QQ3KG', 0, '2020-03-05 01:42:12', NULL, NULL),
(124, 'Thong', 'Tran', '1706 Varsity Dr', 'Woodbridge', 'VA', '22191', NULL, NULL, NULL, 'smartphoneDepot', '$2y$10$HU7n7VbH2Ktint5OCx2UMOC5dKPDf4fumqCsEghu/n9tZCFZoDGKa', 0, '2020-04-23 10:06:28', NULL, NULL),
(125, 'Thong', 'Tran', '1706 Varsity Dr', 'Woodbridge', 'VA', '22191', NULL, NULL, NULL, 'tthong@masonlive.gmu.edu', '$2y$10$zNQI79Ffxp/G2JGqPrzIkulBEcQElLxQDv5wYUyPG5ZHwLdxIRKO6', 0, '2020-04-23 10:12:39', NULL, NULL),
(126, 'Thong', 'Tran', '1706 Varsity Dr', 'Woodbridge', 'VA', '22191', NULL, NULL, NULL, 'user6', '$2y$10$Cov8OEln34ml7hkTYhlz0e8z87Md3lg/UL3Xkqn2.OFnk711He8xe', 0, '2020-04-23 10:16:03', NULL, NULL),
(127, 'Thong', 'Tran', '1706 Varsity Dr', 'Woodbridge', 'VA', '22191', NULL, NULL, NULL, 'smarphone', '$2y$10$fXyqfTm/x0TIsfqeh.z/r.ZwNG9rdfK2tQslbJONAFhTpZbEIOz8K', 0, '2020-04-23 10:21:12', NULL, NULL),
(128, 'Thong', 'Tran', '1706 Varsity Dr', 'Woodbridge', 'VA', '22191', NULL, NULL, NULL, 'itanguyen', '$2y$10$ZpzPodUehVd1JEBx6pjVz.T0dzuR1Xb10VVlaxrV4G1OhBpNyTSuG', 0, '2020-04-23 12:44:54', NULL, NULL),
(129, 'Thong', 'Tran', '1706 Varsity Dr', 'Woodbridge', 'VA', '22191', NULL, NULL, NULL, 'itanguyen1', '$2y$10$L1XXLwcnqWkYwPJ.4Rc4KeGqgk9Hc/iV1ogEn4nLWTefsqKw8EaGy', 0, '2020-04-23 12:46:33', NULL, NULL),
(130, 'Thong', 'Tran', '1706 Varsity Dr', 'Woodbridge', 'VA', '22191', NULL, NULL, NULL, 'alina', '$2y$10$zHTLRG3LVsJvb.63aXmu1ONvZ4.VBLrzF7HSHaXpM7FuiAel5Mfk2', 0, '2020-04-28 21:14:03', NULL, NULL),
(131, 'Alina', 'Tran', '1706 Varsity Dr', 'Woodbridge', 'VA', '22191', NULL, NULL, NULL, 'timtran123', '$2y$10$bq5IPbliEbW8fT0VfGk2XuvcLWxixBO.E0vxIe2r5Ar7Y8jOEXx2a', 0, '2020-04-28 21:23:08', NULL, NULL),
(132, 'Alina', 'Tran', '1706 Varsity Dr', 'Woodbridge', 'VA', '22191', NULL, NULL, NULL, 'timtran2', '$2y$10$vwKaj15w04GowmeHqw2zOu0fGa339gjQF1nODJDHgWXBTgg9jBE2a', 0, '2020-04-28 21:32:23', NULL, NULL),
(133, 'Alina', 'Tran', '1706 Varsity Dr', 'Woodbridge', 'VA', '22191', NULL, NULL, NULL, 'alinatran', '$2y$10$nKPZpap260IYbeoxu7d/GuVUGoHB33aIuFL5wYdsKHC0SrHzfhTDG', 0, '2020-04-29 15:40:04', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sp_shop_sales`
--

CREATE TABLE `sp_shop_sales` (
  `idshopper` int(8) DEFAULT NULL,
  `total` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sp_tax`
--

CREATE TABLE `sp_tax` (
  `idState` int(2) NOT NULL,
  `State` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TaxRate` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp_tax`
--

INSERT INTO `sp_tax` (`idState`, `State`, `TaxRate`) VALUES
(1, 'VA', 0.045),
(2, 'NC', 0.03),
(3, 'DC', 0.06);

-- --------------------------------------------------------

--
-- Table structure for table `sp_trans_log`
--

CREATE TABLE `sp_trans_log` (
  `idlog` int(8) NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currentdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `errmsg` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp_trans_log`
--

INSERT INTO `sp_trans_log` (`idlog`, `name`, `currentdate`, `errmsg`) VALUES
(1, 'smartphoneDepot', '2020-03-05 14:13:35', 'this user processed sale'),
(2, 'smartphoneDepot', '2020-03-05 14:23:55', 'this user manualy updated stock quantity of phones ID :11'),
(3, 'smartphoneDepot', '2020-03-06 11:48:07', 'this user manualy updated stock quantity of phones ID :11'),
(4, 'smartphoneDepot', '2020-03-06 11:50:15', 'this user manualy updated stock quantity of phones ID :12'),
(5, 'smartphoneDepot', '2020-03-06 12:08:36', 'this user processed sale'),
(6, 'smartphoneDepot', '2020-03-06 12:35:51', 'this user Add a new Phone: imei# : 123456789871'),
(7, 'smartphoneDepot', '2020-03-06 12:38:47', 'this user Add a new Phone: imei# : 123456789872'),
(8, 'smartphoneDepot', '2020-03-06 12:43:21', 'this user processed sale for Cart# : '),
(9, 'smartphoneDepot', '2020-03-06 13:14:13', 'this user manualy updated stock quantity of phones ID :13'),
(10, 'smartphoneDepot', '2020-03-06 23:52:27', 'this user Add a new Phone: imei# : '),
(11, 'smartphoneDepot', '2020-03-07 00:30:59', 'this user manualy updated stock quantity of phones ID :14'),
(12, 'smartphoneDepot', '2020-03-07 10:40:48', 'this user manualy updated stock quantity of phones ID :15'),
(13, 'smartphoneDepot', '2020-03-07 10:40:58', 'this user manualy updated stock quantity of phones ID :16'),
(14, 'smartphoneDepot', '2020-03-07 10:44:15', 'this user manualy updated stock quantity of phones ID :17'),
(15, 'smartphoneDepot', '2020-03-07 10:48:28', 'this user Add a new Phone: imei# : 123456789874'),
(16, 'user9', '2020-03-07 11:34:59', 'this user processed sale for Cart# : '),
(17, 'user9', '2020-03-07 11:39:53', 'this user manualy updated stock quantity of phones ID :11'),
(18, 'user9', '2020-03-07 11:42:23', 'this user Add a new Phone: imei# : 123456789871'),
(19, 'user9', '2020-03-07 11:42:38', 'this user Add a new Phone: imei# : 123456789872'),
(20, 'user9', '2020-03-07 11:43:21', 'This user process In-Store sale'),
(21, 'smartphoneDepot', '2020-03-10 20:18:41', 'this user Add a new Phone: imei# : 123456789871'),
(22, 'smartphoneDepot', '2020-03-10 20:19:01', 'this user Add a new Phone: imei# : 123456789873'),
(23, 'smartphoneDepot', '2020-03-10 20:19:22', 'this user Add a new Phone: imei# : 123456789874'),
(24, 'smartphoneDepot', '2020-03-10 20:19:39', 'this user Add a new Phone: imei# : 123456789875'),
(25, 'smartphoneDepot', '2020-03-10 21:04:10', 'this user Add a new Phone: imei# : 123456789876'),
(26, 'smartphoneDepot', '2020-03-10 21:04:25', 'this user Add a new Phone: imei# : 123456789878'),
(27, 'smartphoneDepot', '2020-03-10 21:04:38', 'this user Add a new Phone: imei# : 123456789877'),
(28, 'smartphoneDepot', '2020-03-10 21:04:53', 'this user Add a new Phone: imei# : 123456789879'),
(29, 'smartphoneDepot', '2020-03-10 21:38:15', 'this user Add a new Phone: imei# : '),
(30, 'smartphoneDepot', '2020-03-10 21:41:02', 'This user process In-Store sale'),
(31, 'smartphoneDepot', '2020-03-10 21:41:34', 'this user Add a new Phone: imei# : '),
(32, 'smartphoneDepot', '2020-03-10 21:42:54', 'this user Add a new Phone: imei# : '),
(33, 'smartphoneDepot', '2020-03-10 21:46:20', 'this user Add a new Phone: imei# : '),
(34, 'smartphoneDepot', '2020-03-10 21:48:26', 'this user Add a new Phone: imei# : '),
(35, 'smartphoneDepot', '2020-03-10 22:58:27', 'this user Add a new Phone: imei# : '),
(36, 'smartphoneDepot', '2020-03-10 23:00:44', 'this user Add a new Phone: imei# : '),
(37, 'smartphoneDepot', '2020-03-10 23:01:39', 'this user Add a new Phone: imei# : '),
(38, 'smartphoneDepot', '2020-03-10 23:02:18', 'this user Add a new Phone: imei# : 123456789881'),
(39, 'smartphoneDepot', '2020-03-10 23:07:27', 'this user processed sale for Cart# : '),
(40, 'smartphoneDepot', '2020-03-10 23:07:44', 'this user processed sale for Cart# : '),
(41, 'smartphoneDepot', '2020-03-10 23:15:51', 'this user processed sale for Cart# : '),
(42, 'smartphoneDepot', '2020-03-11 20:00:12', 'this user processed sale for Cart# : '),
(43, 'smartphoneDepot', '2020-03-11 20:15:01', 'this user Add a new Phone: imei# : 123456789871'),
(44, 'smartphoneDepot', '2020-03-11 20:29:21', 'this user manualy updated stock quantity of phones ID :11'),
(45, 'smartphoneDepot', '2020-03-25 18:26:45', 'this user Add a new Phone: imei# : 54353454353'),
(46, 'user9', '2020-04-10 12:51:12', 'this user manualy updated stock quantity of phones ID :11'),
(47, 'user9', '2020-04-10 16:41:31', 'this user processed sale for Cart# : '),
(48, 'user9', '2020-04-10 16:44:19', 'this user processed sale for Cart# : '),
(49, 'user9', '2020-04-10 16:49:27', 'this user processed sale for Cart# : '),
(50, 'user9', '2020-04-10 16:52:26', 'this user processed sale for Cart# : '),
(51, 'smartphoneDepot', '2020-04-20 21:13:35', 'this user manualy updated stock quantity of phones ID :19'),
(52, 'smartphoneDepot', '2020-04-20 21:13:52', 'this user manualy updated stock quantity of phones ID :22'),
(53, 'smartphoneDepot', '2020-04-20 21:14:04', 'this user manualy updated stock quantity of phones ID :24'),
(54, 'smartphoneDepot', '2020-04-20 21:14:10', 'this user manualy updated stock quantity of phones ID :18'),
(55, 'smartphoneDepot', '2020-04-20 21:14:20', 'this user manualy updated stock quantity of phones ID :25'),
(56, 'smartphoneDepot', '2020-04-20 21:14:27', 'this user manualy updated stock quantity of phones ID :26'),
(57, 'smartphoneDepot', '2020-04-22 18:42:35', 'this user Add a new Phone: imei# : 1234567890'),
(58, 'smartphoneDepot', '2020-04-22 18:44:17', 'this user manualy updated stock quantity of phones ID :11'),
(59, 'smartphoneDepot', '2020-04-22 18:47:45', 'this user Add a new Phone: imei# : 1234567890'),
(60, 'smartphoneDepot', '2020-04-22 18:48:39', 'this user Add a new Phone: imei# : 1234567891'),
(61, 'smartphoneDepot', '2020-04-22 18:48:58', 'this user Add a new Phone: imei# : 1234567892'),
(62, 'smartphoneDepot', '2020-04-22 18:49:14', 'this user Add a new Phone: imei# : 1234567893'),
(63, 'smartphoneDepot', '2020-04-22 18:49:33', 'this user Add a new Phone: imei# : 1234567894'),
(64, 'smartphoneDepot', '2020-04-22 18:49:51', 'this user Add a new Phone: imei# : 1234567895'),
(65, 'smartphoneDepot', '2020-04-22 18:52:34', 'this user Add a new Phone: imei# : 1234567898'),
(66, 'smartphoneDepot', '2020-04-22 18:53:18', 'this user manualy updated stock quantity of phones ID :11'),
(67, 'smartphoneDepot', '2020-04-22 18:55:21', 'this user processed sale for Cart# : '),
(68, 'smartphoneDepot', '2020-04-22 18:55:44', 'this user processed sale for Cart# : '),
(69, 'smartphoneDepot', '2020-04-22 18:59:59', 'this user Add a new Phone: imei# : 1234567890'),
(70, 'smartphoneDepot', '2020-04-22 19:01:04', 'this user manualy updated stock quantity of phones ID :11'),
(71, 'smartphoneDepot', '2020-04-22 19:03:03', 'this user processed sale for Cart# : '),
(72, 'smartphoneDepot', '2020-04-22 19:03:34', 'this user processed sale for Cart# : '),
(73, 'smartphoneDepot', '2020-04-22 19:03:48', 'this user processed sale for Cart# : '),
(74, 'smartphoneDepot', '2020-04-22 20:13:11', 'this user Add a new Phone: imei# : 1234567897'),
(75, 'smartphoneDepot', '2020-04-22 20:14:28', 'this user manualy updated stock quantity of phones ID :20'),
(76, 'smartphoneDepot', '2020-04-22 20:18:26', 'this user Add a new Phone: imei# : 1234567890'),
(77, 'smartphoneDepot', '2020-04-22 20:21:09', 'this user processed sale for Cart# : '),
(78, 'smartphoneDepot', '2020-04-22 20:30:54', 'this user Add a new Phone: imei# : 1234567890'),
(79, 'smartphoneDepot', '2020-04-22 20:31:46', 'this user manualy updated stock quantity of phones ID :11'),
(80, 'smartphoneDepot', '2020-04-22 20:33:57', 'this user processed sale for Cart# : '),
(81, 'smartphoneDepot', '2020-04-24 16:22:22', 'this user Add a new Phone: imei# : 1234567888'),
(82, 'smartphoneDepot', '2020-04-24 16:23:29', 'this user manualy updated stock quantity of phones ID :11'),
(83, 'smartphoneDepot', '2020-04-24 16:25:26', 'this user manualy updated stock quantity of phones ID :20'),
(84, 'smartphoneDepot', '2020-04-24 16:26:25', 'this user Add a new Phone: imei# : 1234567891'),
(85, 'smartphoneDepot', '2020-04-24 16:27:04', 'this user manualy updated stock quantity of phones ID :20'),
(86, 'smartphoneDepot', '2020-04-24 16:28:56', 'this user Add a new Phone: imei# : 1234567890'),
(87, 'smartphoneDepot', '2020-04-24 16:29:53', 'this user manualy updated stock quantity of phones ID :11'),
(88, 'smartphoneDepot', '2020-04-24 16:38:05', 'this user Add a new Phone: imei# : 12345678972'),
(89, 'smartphoneDepot', '2020-04-24 16:38:59', 'this user manualy updated stock quantity of phones ID :11'),
(90, 'smartphoneDepot', '2020-04-24 16:42:06', 'this user Add a new Phone: imei# : 12345678555'),
(91, 'smartphoneDepot', '2020-04-24 16:45:57', 'this user processed sale for Cart# : '),
(92, 'smartphoneDepot', '2020-04-28 21:04:10', 'this user processed sale for Cart# : '),
(95, 'smartphoneDepot', '2020-04-28 21:25:34', 'this user Add a new Phone: imei# : 1234567892'),
(96, 'smartphoneDepot', '2020-04-28 21:25:51', 'this user processed sale for Cart# : '),
(97, 'smartphoneDepot', '2020-04-28 21:26:40', 'this user manualy updated stock quantity of phones ID :11'),
(98, 'smartphoneDepot', '2020-04-28 21:30:29', 'this user manualy updated stock quantity of phones ID :20'),
(99, 'smartphoneDepot', '2020-04-28 21:33:58', 'this user Add a new Phone: imei# : 123456789000'),
(100, 'smartphoneDepot', '2020-04-28 21:34:14', 'this user processed sale for Cart# : '),
(101, 'smartphoneDepot', '2020-04-28 21:35:34', 'this user manualy updated stock quantity of phones ID :11'),
(102, 'smartphoneDepot', '2020-04-29 19:23:19', 'this user processed sale for Cart# : '),
(103, 'smartphoneDepot', '2020-04-29 19:23:38', 'This user process In-Store sale'),
(104, 'smartphoneDepot', '2020-04-29 19:23:56', 'this user Add a new Phone: imei# : 1234567890'),
(105, 'smartphoneDepot', '2020-04-29 19:24:42', 'this user manualy updated stock quantity of phones ID :11'),
(106, 'smartphoneDepot', '2020-05-01 19:25:48', 'this user manualy updated stock quantity of phones ID :20'),
(107, 'smartphoneDepot', '2020-05-01 19:26:02', 'this user manualy updated stock quantity of phones ID :27'),
(108, 'smartphoneDepot', '2020-05-01 19:26:11', 'this user manualy updated stock quantity of phones ID :23'),
(109, 'smartphoneDepot', '2020-05-01 19:26:22', 'this user manualy updated stock quantity of phones ID :28'),
(110, 'smartphoneDepot', '2020-05-01 19:29:01', 'this user Add a new Phone: imei# : 1234567891');

-- --------------------------------------------------------

--
-- Table structure for table `sp_updatephonestock`
--

CREATE TABLE `sp_updatephonestock` (
  `idforphone` int(16) NOT NULL,
  `PhoneName` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Description` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PhoneType` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `storageGB` int(5) NOT NULL,
  `grade` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `PhoneSku` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `oldstock` int(8) DEFAULT NULL,
  `dateChanged` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Type` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sp_updatephonestock`
--

INSERT INTO `sp_updatephonestock` (`idforphone`, `PhoneName`, `Description`, `PhoneType`, `storageGB`, `grade`, `Price`, `PhoneSku`, `oldstock`, `dateChanged`, `Type`) VALUES
(1, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '', 96, '2020-03-06 11:49:12', 'U'),
(2, 'iphone X', 'iphone X, 64 GB ', 'iphoneX', 64, 'green', 599.99, '', 12, '2020-03-06 11:50:15', 'U'),
(3, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '', 100, '2020-03-06 12:07:43', 'UPDATE'),
(4, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '', 98, '2020-03-06 12:35:51', 'UPDATE'),
(5, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '', 99, '2020-03-06 12:38:47', 'UPDATE'),
(6, 'iphone X', 'iphone X, 64 GB ', 'iphoneX', 64, 'yellow', 499.99, '13', 15, '2020-03-06 13:14:13', 'UPDATE'),
(7, 'iphone X', 'iphone X, 128 GB', 'iphoneX', 128, 'orange', 799.99, '14', 2, '2020-03-07 00:30:59', 'UPDATE'),
(8, 'iphone X', 'iphone X, 128 GB', 'iphoneX', 128, 'green', 699.99, '15', 2, '2020-03-07 10:40:48', 'UPDATE'),
(9, 'iphone X', 'iphone X, 128 GB', 'iphoneX', 128, 'yellow', 599.99, '16', 10, '2020-03-07 10:40:58', 'UPDATE'),
(10, 'iphone X', 'iphone X, 256 GB ', 'iphoneX', 256, 'orange', 899.99, '17', 2, '2020-03-07 10:44:15', 'UPDATE'),
(11, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 100, '2020-03-07 10:48:07', 'UPDATE'),
(12, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 98, '2020-03-07 10:48:28', 'UPDATE'),
(13, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 99, '2020-03-07 11:39:53', 'UPDATE'),
(14, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 100, '2020-03-07 11:42:23', 'UPDATE'),
(15, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 101, '2020-03-07 11:42:38', 'UPDATE'),
(16, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 102, '2020-03-10 20:18:40', 'UPDATE'),
(17, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'orange', 799.99, '20', 1, '2020-03-10 20:19:01', 'UPDATE'),
(18, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 103, '2020-03-10 20:19:22', 'UPDATE'),
(19, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'orange', 799.99, '20', 2, '2020-03-10 20:19:39', 'UPDATE'),
(20, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 104, '2020-03-10 21:04:10', 'UPDATE'),
(21, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 105, '2020-03-10 21:04:25', 'UPDATE'),
(22, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 106, '2020-03-10 21:04:38', 'UPDATE'),
(23, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 107, '2020-03-10 21:04:53', 'UPDATE'),
(24, 'Iphone 12', 'Iphone 12 Midnight Green, 64 GB', 'iphone12', 64, 'orange', 799.98, '31', 0, '2020-03-10 23:02:18', 'UPDATE'),
(25, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 108, '2020-03-10 23:15:26', 'UPDATE'),
(26, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 106, '2020-03-11 20:15:01', 'UPDATE'),
(27, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 107, '2020-03-11 20:29:21', 'UPDATE'),
(28, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 123, '2020-03-18 19:46:04', 'UPDATE'),
(29, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'orange', 799.99, '20', 3, '2020-03-20 10:48:46', 'UPDATE'),
(30, 'iphone X', 'iphone X, 128 GB', 'iphoneX', 128, 'yellow', 599.99, '16', 100, '2020-03-20 23:06:09', 'UPDATE'),
(31, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 121, '2020-03-25 17:56:45', 'UPDATE'),
(32, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 119, '2020-03-25 18:41:41', 'UPDATE'),
(33, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', 1, '2020-03-27 12:35:32', 'UPDATE'),
(34, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', 0, '2020-03-27 13:04:57', 'UPDATE'),
(35, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -1, '2020-03-27 13:07:01', 'UPDATE'),
(36, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -2, '2020-03-27 13:09:09', 'UPDATE'),
(37, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -3, '2020-03-27 13:10:00', 'UPDATE'),
(38, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -4, '2020-03-28 09:12:04', 'UPDATE'),
(39, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -5, '2020-03-28 09:18:47', 'UPDATE'),
(40, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -6, '2020-03-28 09:21:14', 'UPDATE'),
(41, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -7, '2020-03-28 09:23:31', 'UPDATE'),
(42, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -8, '2020-03-28 09:34:22', 'UPDATE'),
(43, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -9, '2020-03-28 09:36:45', 'UPDATE'),
(44, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -10, '2020-03-28 10:42:42', 'UPDATE'),
(45, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -11, '2020-03-30 08:37:31', 'UPDATE'),
(46, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -12, '2020-04-10 12:28:46', 'UPDATE'),
(47, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 117, '2020-04-10 12:51:12', 'UPDATE'),
(48, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -13, '2020-04-10 12:55:58', 'UPDATE'),
(49, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -14, '2020-04-10 12:56:35', 'UPDATE'),
(50, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -15, '2020-04-16 19:03:10', 'UPDATE'),
(51, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -16, '2020-04-16 21:06:50', 'UPDATE'),
(52, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -17, '2020-04-16 21:07:40', 'UPDATE'),
(53, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -18, '2020-04-16 21:12:25', 'UPDATE'),
(54, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -19, '2020-04-16 21:14:59', 'UPDATE'),
(55, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -20, '2020-04-18 12:41:09', 'UPDATE'),
(56, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -21, '2020-04-18 12:46:48', 'UPDATE'),
(57, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -22, '2020-04-20 20:52:55', 'UPDATE'),
(58, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'orange', 699.99, '11', 116, '2020-04-20 20:55:46', 'UPDATE'),
(59, 'iphone X', 'iphone X, 64 GB ', 'iphoneX', 64, 'green', 599.99, '12', 100, '2020-04-20 20:55:53', 'UPDATE'),
(60, 'iphone X', 'iphone X, 64 GB ', 'iphoneX', 64, 'yellow', 499.99, '13', 100, '2020-04-20 20:56:03', 'UPDATE'),
(61, 'iphone X', 'iphone X, 128 GB', 'iphoneX', 128, 'orange', 799.99, '14', 100, '2020-04-20 20:56:07', 'UPDATE'),
(62, 'iphone X', 'iphone X, 128 GB', 'iphoneX', 128, 'green', 699.99, '15', 100, '2020-04-20 20:56:11', 'UPDATE'),
(63, 'iphone X', 'iphone X, 128 GB', 'iphoneX', 128, 'yellow', 599.99, '16', 98, '2020-04-20 20:56:15', 'UPDATE'),
(64, 'iphone X', 'iphone X, 256 GB ', 'iphoneX', 256, 'orange', 899.99, '17', 100, '2020-04-20 20:56:18', 'UPDATE'),
(65, 'iphone X', 'iphone X, 256 GB ', 'iphoneX', 256, 'green', 799.99, '18', 2, '2020-04-20 20:56:22', 'UPDATE'),
(66, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'yellow', 699.99, '19', -23, '2020-04-20 20:56:25', 'UPDATE'),
(67, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'orange', 799.99, '20', 2, '2020-04-20 20:56:33', 'UPDATE'),
(68, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'green', 699.99, '21', 2, '2020-04-20 20:56:36', 'UPDATE'),
(69, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'yellow', 599.99, '22', 0, '2020-04-20 20:56:41', 'UPDATE'),
(70, 'iphone XS', 'iphone XS, 128 GB ', 'iphoneXS', 128, 'orange', 899.99, '23', 1, '2020-04-20 20:56:45', 'UPDATE'),
(71, 'iphone XS', 'iphone XS, 128 GB ', 'iphoneXS', 128, 'green', 799.99, '24', 0, '2020-04-20 20:56:49', 'UPDATE'),
(72, 'iphone XS', 'iphone XS, 128 GB ', 'iphoneXS', 128, 'yellow', 699.99, '25', 0, '2020-04-20 20:56:52', 'UPDATE'),
(73, 'iphone XS', 'iphone XS, 256 GB ', 'iphoneXS', 256, 'orange', 999.99, '26', 0, '2020-04-20 20:56:55', 'UPDATE'),
(74, 'iphone XS', 'iphone XS, 256 GB ', 'iphoneXS', 256, 'green', 899.99, '27', 0, '2020-04-20 20:57:00', 'UPDATE'),
(75, 'iphone XS', 'iphone XS, 256 GB ', 'iphoneXS', 256, 'yellow', 799.99, '28', 0, '2020-04-20 20:57:04', 'UPDATE'),
(76, 'Iphone 12', 'Iphone 12 Midnight Green, 64 GB', 'iphone12', 64, 'orange', 799.98, '31', 1, '2020-04-20 20:57:08', 'UPDATE'),
(77, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'C', 699.99, '19', -23, '2020-04-20 21:13:35', 'UPDATE'),
(78, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'C', 599.99, '22', 0, '2020-04-20 21:13:52', 'UPDATE'),
(79, 'iphone XS', 'iphone XS, 128 GB ', 'iphoneXS', 128, 'B', 799.99, '24', 0, '2020-04-20 21:14:04', 'UPDATE'),
(80, 'iphone X', 'iphone X, 256 GB ', 'iphoneX', 256, 'B', 799.99, '18', 2, '2020-04-20 21:14:10', 'UPDATE'),
(81, 'iphone XS', 'iphone XS, 128 GB ', 'iphoneXS', 128, 'C', 699.99, '25', 0, '2020-04-20 21:14:20', 'UPDATE'),
(82, 'iphone XS', 'iphone XS, 256 GB ', 'iphoneXS', 256, 'A', 999.99, '26', 0, '2020-04-20 21:14:27', 'UPDATE'),
(83, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'C', 699.99, '19', 100, '2020-04-20 21:20:13', 'UPDATE'),
(84, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'C', 699.99, '19', 99, '2020-04-20 21:21:32', 'UPDATE'),
(85, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'C', 699.99, '19', 98, '2020-04-20 21:22:24', 'UPDATE'),
(86, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'C', 699.99, '19', 97, '2020-04-20 23:25:33', 'UPDATE'),
(87, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'C', 699.99, '19', 96, '2020-04-20 23:29:25', 'UPDATE'),
(88, 'iphone X', 'iphone X, 256 GB', 'iphoneX', 256, 'C', 699.99, '19', 95, '2020-04-20 23:30:08', 'UPDATE'),
(89, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'B', 699.99, '21', 2, '2020-04-20 23:33:11', 'UPDATE'),
(90, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'B', 699.99, '21', 1, '2020-04-20 23:53:31', 'UPDATE'),
(91, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'B', 699.99, '21', 0, '2020-04-20 23:58:25', 'UPDATE'),
(92, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'B', 699.99, '21', -1, '2020-04-21 00:00:26', 'UPDATE'),
(93, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'B', 699.99, '21', -2, '2020-04-21 00:02:14', 'UPDATE'),
(94, 'iphone XS', 'iphone XS, 128 GB ', 'iphoneXS', 128, 'C', 699.99, '25', 100, '2020-04-21 12:20:00', 'UPDATE'),
(95, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'B', 699.99, '21', -3, '2020-04-21 13:25:50', 'UPDATE'),
(96, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'B', 699.99, '21', -5, '2020-04-21 14:21:40', 'UPDATE'),
(97, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'B', 699.99, '21', -7, '2020-04-21 17:12:02', 'UPDATE'),
(98, 'Iphone 12', 'Iphone 12 Midnight Green, 64 GB', 'iphone12', 64, 'A', 799.98, '31', 1, '2020-04-21 17:12:06', 'UPDATE'),
(99, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'B', 699.99, '21', 10, '2020-04-21 20:32:36', 'UPDATE'),
(100, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'B', 699.99, '21', 9, '2020-04-22 12:50:49', 'UPDATE'),
(101, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 2, '2020-04-22 12:55:15', 'UPDATE'),
(102, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 1, '2020-04-22 13:04:23', 'UPDATE'),
(103, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 0, '2020-04-22 13:17:12', 'UPDATE'),
(104, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', -2, '2020-04-22 13:29:55', 'UPDATE'),
(105, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'B', 699.99, '21', 6, '2020-04-22 13:31:53', 'UPDATE'),
(106, 'iphone XS', 'iphone XS, 64 GB ', 'iphoneXS', 64, 'B', 699.99, '21', 5, '2020-04-22 18:02:09', 'UPDATE'),
(107, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'A', 699.99, '11', 116, '2020-04-22 18:44:17', 'UPDATE'),
(108, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', -4, '2020-04-22 18:44:49', 'UPDATE'),
(109, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'A', 699.99, '11', 100, '2020-04-22 18:53:18', 'UPDATE'),
(110, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', -5, '2020-04-22 18:54:24', 'UPDATE'),
(111, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'A', 699.99, '11', 110, '2020-04-22 19:01:04', 'UPDATE'),
(112, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', -6, '2020-04-22 19:02:25', 'UPDATE'),
(113, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', -8, '2020-04-22 20:14:28', 'UPDATE'),
(114, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 3, '2020-04-22 20:20:33', 'UPDATE'),
(115, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'A', 699.99, '11', 100, '2020-04-22 20:31:46', 'UPDATE'),
(116, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 2, '2020-04-22 20:32:57', 'UPDATE'),
(117, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 1, '2020-04-22 22:21:22', 'UPDATE'),
(118, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 0, '2020-04-22 22:26:26', 'UPDATE'),
(119, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', -1, '2020-04-23 10:01:57', 'UPDATE'),
(120, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', -3, '2020-04-23 12:50:05', 'UPDATE'),
(121, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', -5, '2020-04-23 18:17:32', 'UPDATE'),
(122, 'iphone XS', 'iphone XS, 128 GB ', 'iphoneXS', 128, 'C', 699.99, '25', 99, '2020-04-23 18:22:38', 'UPDATE'),
(123, 'iphone XS', 'iphone XS, 128 GB ', 'iphoneXS', 128, 'C', 699.99, '25', 98, '2020-04-24 12:06:29', 'UPDATE'),
(124, 'iphone XS', 'iphone XS, 128 GB ', 'iphoneXS', 128, 'C', 699.99, '25', 97, '2020-04-24 12:14:44', 'UPDATE'),
(125, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', -6, '2020-04-24 12:19:04', 'UPDATE'),
(126, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'A', 699.99, '11', 110, '2020-04-24 16:23:29', 'UPDATE'),
(127, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', -7, '2020-04-24 16:25:26', 'UPDATE'),
(128, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 10, '2020-04-24 16:27:04', 'UPDATE'),
(129, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'A', 699.99, '11', 100, '2020-04-24 16:29:53', 'UPDATE'),
(130, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'A', 699.99, '11', 101, '2020-04-24 16:38:59', 'UPDATE'),
(131, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 4, '2020-04-24 16:45:23', 'UPDATE'),
(132, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 3, '2020-04-28 21:03:24', 'UPDATE'),
(133, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'A', 699.99, '11', 110, '2020-04-28 21:05:43', 'UPDATE'),
(134, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 2, '2020-04-28 21:09:46', 'UPDATE'),
(135, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 1, '2020-04-28 21:24:20', 'UPDATE'),
(136, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'A', 699.99, '11', 100, '2020-04-28 21:26:40', 'UPDATE'),
(137, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 0, '2020-04-28 21:30:29', 'UPDATE'),
(138, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 4, '2020-04-28 21:33:11', 'UPDATE'),
(139, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'A', 699.99, '11', 101, '2020-04-28 21:35:34', 'UPDATE'),
(140, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 3, '2020-04-29 19:22:46', 'UPDATE'),
(141, 'iphone X', 'iphone X, 64 GB', 'iphoneX', 64, 'A', 699.99, '11', 102, '2020-04-29 19:24:42', 'UPDATE'),
(142, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 2, '2020-04-29 19:27:41', 'UPDATE'),
(143, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 1, '2020-05-01 19:21:25', 'UPDATE'),
(144, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 100, '2020-05-01 19:22:22', 'UPDATE'),
(145, 'iphone XS', 'iphone XS, 64 GB', 'iphoneXS', 64, 'A', 799.99, '20', 92, '2020-05-01 19:25:48', 'UPDATE'),
(146, 'iphone XS', 'iphone XS, 256 GB ', 'iphoneXS', 256, 'B', 899.99, '27', 0, '2020-05-01 19:26:02', 'UPDATE'),
(147, 'iphone XS', 'iphone XS, 128 GB ', 'iphoneXS', 128, 'A', 899.99, '23', 1, '2020-05-01 19:26:11', 'UPDATE'),
(148, 'iphone XS', 'iphone XS, 256 GB ', 'iphoneXS', 256, 'C', 799.99, '28', 0, '2020-05-01 19:26:22', 'UPDATE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `colors`
--
ALTER TABLE `colors`
  ADD PRIMARY KEY (`C_ID`);

--
-- Indexes for table `loginadmin`
--
ALTER TABLE `loginadmin`
  ADD PRIMARY KEY (`idadmin`),
  ADD UNIQUE KEY `adminUsername` (`adminUsername`);

--
-- Indexes for table `phones`
--
ALTER TABLE `phones`
  ADD PRIMARY KEY (`P_ID`);

--
-- Indexes for table `phone_colors`
--
ALTER TABLE `phone_colors`
  ADD PRIMARY KEY (`PC_ID`),
  ADD KEY `C_ID` (`C_ID`),
  ADD KEY `P_OPT_ID` (`P_OPT_ID`);

--
-- Indexes for table `phone_grades`
--
ALTER TABLE `phone_grades`
  ADD PRIMARY KEY (`P_GRADE_ID`);

--
-- Indexes for table `phone_options`
--
ALTER TABLE `phone_options`
  ADD PRIMARY KEY (`P_OPT_ID`),
  ADD KEY `P_ID` (`P_ID`),
  ADD KEY `P_GRADE_ID` (`P_GRADE_ID`),
  ADD KEY `P_STG_ID` (`P_STG_ID`);

--
-- Indexes for table `phone_storage`
--
ALTER TABLE `phone_storage`
  ADD PRIMARY KEY (`P_STG_ID`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sp_for_smartphoneid` (`idSmartPhones`);

--
-- Indexes for table `sp_cart`
--
ALTER TABLE `sp_cart`
  ADD PRIMARY KEY (`idCart`),
  ADD KEY `basket_idshopper_fk` (`idShopper`);

--
-- Indexes for table `sp_cartitem`
--
ALTER TABLE `sp_cartitem`
  ADD PRIMARY KEY (`idCartItem`),
  ADD KEY `basktitems_bsktid_fk` (`idCart`),
  ADD KEY `basktitems_idprod_fk` (`idSmartPhones`),
  ADD KEY `phone_option_idopt_fk` (`P_OPT_ID`);

--
-- Indexes for table `sp_cartstatus`
--
ALTER TABLE `sp_cartstatus`
  ADD PRIMARY KEY (`idStatus`),
  ADD KEY `BasketStatuses_idCart_fk` (`idCart`);

--
-- Indexes for table `sp_companycustomer`
--
ALTER TABLE `sp_companycustomer`
  ADD PRIMARY KEY (`idCustomer`);

--
-- Indexes for table `sp_department`
--
ALTER TABLE `sp_department`
  ADD PRIMARY KEY (`idDepartment`);

--
-- Indexes for table `sp_expense`
--
ALTER TABLE `sp_expense`
  ADD PRIMARY KEY (`idexpense`);

--
-- Indexes for table `sp_invoiceitems`
--
ALTER TABLE `sp_invoiceitems`
  ADD PRIMARY KEY (`idInvoice`,`iditems`),
  ADD KEY `idinvoice_items_fk` (`iditems`);

--
-- Indexes for table `sp_invoicephone`
--
ALTER TABLE `sp_invoicephone`
  ADD PRIMARY KEY (`idInvoice`),
  ADD KEY `idinvoice_idcustomer_fk` (`idCustomer`);

--
-- Indexes for table `sp_items`
--
ALTER TABLE `sp_items`
  ADD PRIMARY KEY (`iditems`);

--
-- Indexes for table `sp_online_orderprocess_record`
--
ALTER TABLE `sp_online_orderprocess_record`
  ADD PRIMARY KEY (`idonlineProcess`);

--
-- Indexes for table `sp_phones`
--
ALTER TABLE `sp_phones`
  ADD PRIMARY KEY (`idSmartPhones`),
  ADD KEY `prodduct_idDept_fk` (`idDepartment`);

--
-- Indexes for table `sp_phonesoption`
--
ALTER TABLE `sp_phonesoption`
  ADD PRIMARY KEY (`idSmartPhonesoption`),
  ADD KEY `prodoption_prodid_fk` (`idSmartPhones`);

--
-- Indexes for table `sp_phonesoptioncategory`
--
ALTER TABLE `sp_phonesoptioncategory`
  ADD PRIMARY KEY (`idOptionCategory`);

--
-- Indexes for table `sp_phonesoptiondetail`
--
ALTER TABLE `sp_phonesoptiondetail`
  ADD PRIMARY KEY (`idoption`),
  ADD KEY `prodoptdettail_idoptcat_fk` (`idOptionCategory`);

--
-- Indexes for table `sp_phonespos`
--
ALTER TABLE `sp_phonespos`
  ADD PRIMARY KEY (`idphonepos`);

--
-- Indexes for table `sp_phones_request`
--
ALTER TABLE `sp_phones_request`
  ADD PRIMARY KEY (`idRequest`),
  ADD KEY `prodrequest_idprod_fk` (`idSmartPhones`);

--
-- Indexes for table `sp_phonetype`
--
ALTER TABLE `sp_phonetype`
  ADD PRIMARY KEY (`idphonetype`);

--
-- Indexes for table `sp_phone_onlinesell_record`
--
ALTER TABLE `sp_phone_onlinesell_record`
  ADD PRIMARY KEY (`idonlineSaleHistory`);

--
-- Indexes for table `sp_phone_sales_history`
--
ALTER TABLE `sp_phone_sales_history`
  ADD PRIMARY KEY (`idSaleHistory`);

--
-- Indexes for table `sp_promolist`
--
ALTER TABLE `sp_promolist`
  ADD UNIQUE KEY `promote_uk` (`idshopper`,`month`,`year`);

--
-- Indexes for table `sp_purchasevendor`
--
ALTER TABLE `sp_purchasevendor`
  ADD PRIMARY KEY (`idpurchase`);

--
-- Indexes for table `sp_shipping`
--
ALTER TABLE `sp_shipping`
  ADD PRIMARY KEY (`idRange`);

--
-- Indexes for table `sp_shopper`
--
ALTER TABLE `sp_shopper`
  ADD PRIMARY KEY (`idShopper`);

--
-- Indexes for table `sp_tax`
--
ALTER TABLE `sp_tax`
  ADD PRIMARY KEY (`idState`);

--
-- Indexes for table `sp_trans_log`
--
ALTER TABLE `sp_trans_log`
  ADD PRIMARY KEY (`idlog`);

--
-- Indexes for table `sp_updatephonestock`
--
ALTER TABLE `sp_updatephonestock`
  ADD PRIMARY KEY (`idforphone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `colors`
--
ALTER TABLE `colors`
  MODIFY `C_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `loginadmin`
--
ALTER TABLE `loginadmin`
  MODIFY `idadmin` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `phones`
--
ALTER TABLE `phones`
  MODIFY `P_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `phone_colors`
--
ALTER TABLE `phone_colors`
  MODIFY `PC_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `phone_grades`
--
ALTER TABLE `phone_grades`
  MODIFY `P_GRADE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `phone_options`
--
ALTER TABLE `phone_options`
  MODIFY `P_OPT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `phone_storage`
--
ALTER TABLE `phone_storage`
  MODIFY `P_STG_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `sp_cart`
--
ALTER TABLE `sp_cart`
  MODIFY `idCart` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;

--
-- AUTO_INCREMENT for table `sp_cartitem`
--
ALTER TABLE `sp_cartitem`
  MODIFY `idCartItem` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;

--
-- AUTO_INCREMENT for table `sp_cartstatus`
--
ALTER TABLE `sp_cartstatus`
  MODIFY `idStatus` int(8) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sp_companycustomer`
--
ALTER TABLE `sp_companycustomer`
  MODIFY `idCustomer` int(8) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sp_department`
--
ALTER TABLE `sp_department`
  MODIFY `idDepartment` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sp_expense`
--
ALTER TABLE `sp_expense`
  MODIFY `idexpense` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `sp_invoicephone`
--
ALTER TABLE `sp_invoicephone`
  MODIFY `idInvoice` int(8) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sp_items`
--
ALTER TABLE `sp_items`
  MODIFY `iditems` int(8) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sp_online_orderprocess_record`
--
ALTER TABLE `sp_online_orderprocess_record`
  MODIFY `idonlineProcess` int(8) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sp_phones`
--
ALTER TABLE `sp_phones`
  MODIFY `idSmartPhones` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `sp_phonespos`
--
ALTER TABLE `sp_phonespos`
  MODIFY `idphonepos` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `sp_phonetype`
--
ALTER TABLE `sp_phonetype`
  MODIFY `idphonetype` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `sp_phone_onlinesell_record`
--
ALTER TABLE `sp_phone_onlinesell_record`
  MODIFY `idonlineSaleHistory` int(8) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sp_phone_sales_history`
--
ALTER TABLE `sp_phone_sales_history`
  MODIFY `idSaleHistory` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `sp_promolist`
--
ALTER TABLE `sp_promolist`
  MODIFY `idshopper` int(8) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sp_purchasevendor`
--
ALTER TABLE `sp_purchasevendor`
  MODIFY `idpurchase` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `sp_shopper`
--
ALTER TABLE `sp_shopper`
  MODIFY `idShopper` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;

--
-- AUTO_INCREMENT for table `sp_trans_log`
--
ALTER TABLE `sp_trans_log`
  MODIFY `idlog` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `sp_updatephonestock`
--
ALTER TABLE `sp_updatephonestock`
  MODIFY `idforphone` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `phone_colors`
--
ALTER TABLE `phone_colors`
  ADD CONSTRAINT `phone_colors_ibfk_1` FOREIGN KEY (`C_ID`) REFERENCES `colors` (`C_ID`),
  ADD CONSTRAINT `phone_colors_ibfk_2` FOREIGN KEY (`P_OPT_ID`) REFERENCES `phone_options` (`P_OPT_ID`);

--
-- Constraints for table `phone_options`
--
ALTER TABLE `phone_options`
  ADD CONSTRAINT `phone_options_ibfk_1` FOREIGN KEY (`P_ID`) REFERENCES `phones` (`P_ID`),
  ADD CONSTRAINT `phone_options_ibfk_2` FOREIGN KEY (`P_GRADE_ID`) REFERENCES `phone_grades` (`P_GRADE_ID`),
  ADD CONSTRAINT `phone_options_ibfk_3` FOREIGN KEY (`P_STG_ID`) REFERENCES `phone_storage` (`P_STG_ID`);

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `sp_for_smartphoneid` FOREIGN KEY (`idSmartPhones`) REFERENCES `sp_phones` (`idSmartPhones`);

--
-- Constraints for table `sp_cart`
--
ALTER TABLE `sp_cart`
  ADD CONSTRAINT `basket_idshopper_fk` FOREIGN KEY (`idShopper`) REFERENCES `sp_shopper` (`idShopper`);

--
-- Constraints for table `sp_cartitem`
--
ALTER TABLE `sp_cartitem`
  ADD CONSTRAINT `basktitems_bsktid_fk` FOREIGN KEY (`idCart`) REFERENCES `sp_cart` (`idCart`),
  ADD CONSTRAINT `basktitems_idprod_fk` FOREIGN KEY (`idSmartPhones`) REFERENCES `sp_phones` (`idSmartPhones`),
  ADD CONSTRAINT `phone_option_idopt_fk` FOREIGN KEY (`P_OPT_ID`) REFERENCES `phone_options` (`P_OPT_ID`);

--
-- Constraints for table `sp_cartstatus`
--
ALTER TABLE `sp_cartstatus`
  ADD CONSTRAINT `BasketStatuses_idCart_fk` FOREIGN KEY (`idCart`) REFERENCES `sp_cart` (`idCart`);

--
-- Constraints for table `sp_invoiceitems`
--
ALTER TABLE `sp_invoiceitems`
  ADD CONSTRAINT `idinvoice_invoiceitems_fk` FOREIGN KEY (`idInvoice`) REFERENCES `sp_invoicephone` (`idInvoice`),
  ADD CONSTRAINT `idinvoice_items_fk` FOREIGN KEY (`iditems`) REFERENCES `sp_items` (`iditems`);

--
-- Constraints for table `sp_invoicephone`
--
ALTER TABLE `sp_invoicephone`
  ADD CONSTRAINT `idinvoice_idcustomer_fk` FOREIGN KEY (`idCustomer`) REFERENCES `sp_companycustomer` (`idCustomer`);

--
-- Constraints for table `sp_phones`
--
ALTER TABLE `sp_phones`
  ADD CONSTRAINT `prodduct_idDept_fk` FOREIGN KEY (`idDepartment`) REFERENCES `sp_department` (`idDepartment`);

--
-- Constraints for table `sp_phonesoption`
--
ALTER TABLE `sp_phonesoption`
  ADD CONSTRAINT `smartphone_idphone_fk` FOREIGN KEY (`idSmartPhones`) REFERENCES `sp_phones` (`idSmartPhones`);

--
-- Constraints for table `sp_phonesoptiondetail`
--
ALTER TABLE `sp_phonesoptiondetail`
  ADD CONSTRAINT `prodoptdettail_idoptcat_fk` FOREIGN KEY (`idOptionCategory`) REFERENCES `sp_phonesoptioncategory` (`idOptionCategory`);

--
-- Constraints for table `sp_promolist`
--
ALTER TABLE `sp_promolist`
  ADD CONSTRAINT `promote_idshopper_fk` FOREIGN KEY (`idshopper`) REFERENCES `sp_shopper` (`idShopper`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
