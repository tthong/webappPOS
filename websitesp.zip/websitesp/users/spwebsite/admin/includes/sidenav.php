<div id="sidenav">
			
			<h2 class = "texts">Main Feature</h2>
			<ul class = "lab">
				<li> <a href="index.php">Home</a></li>
				<li> <a href="createUserAccount.php">User Managerment</a></li>
				<li> <a href="onlinesellordered.php">Online Sell</a></li>
				<li> <a href="instoresell.php">Instore Sell</a></li>
				<li> <a href="products.php">Products</a></li>
				<li> <a href="purchase.php">Purchase</a></li>
				<li> <a href="expense.php">Expenses</a></li>
				<li> <a href="stock.php">Stock</a></li>
			</ul>
			
			<h2 class = "texts">Report</h2>
			<ul class ="lab">
				<li> <a href="#">Sell Report</a></li>
				<li> <a href="#">Phone Purchase Report</a></li>
				<li> <a href="#">Phone Payment Report</a></li>
				<li> <a href="#">Sell Payment Report</a></li>
				<li> <a href="#">Expense Report</a></li>
				<li> <a href="#">Customer Statment</a></li>
				<li> <a href="#">Profit/Loss Report</a></li>
				<li> <a href="#">Tax Report</a></li>
				<li> <a href="#">Stock Report</a></li>
				<li> <a href="#">Items Report</a></li>
				<li> <a href="#">Customer Statment</a></li>
			</ul>
		</div>