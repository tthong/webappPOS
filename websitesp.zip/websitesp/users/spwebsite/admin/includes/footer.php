<div id = "footer"> <p>@SamrtPhone Depot</p>
						<p> copyright ! SmartPhone Depot</p>
			</div>