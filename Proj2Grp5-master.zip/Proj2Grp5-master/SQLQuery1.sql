﻿use Project2_Group5
create user Administrator for login [EC2AMAZ-U589EDM\Administrator];
go