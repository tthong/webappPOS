﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Project2_Group5.Models;

namespace Project2_Group5.DAL
{
    public class Project2_Group5Context:DbContext
    {
    
        public DbSet<Applicant> Applicants  { get; set; }
        public DbSet<Major> Majors  { get; set; }
    }
}