﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Project2_Group5.DAL;
using Project2_Group5.Models;

namespace Project2_Group5.Controllers
{


    [Authorize]
    public class ApplicantsController : Controller
    {
        private Project2_Group5Context db = new Project2_Group5Context();

        // GET: Applicants
        //TODO: double check parameters (MN)
        public ActionResult Index(string major, string search)
        {
            var applicants = db.Applicants.Include(a => a.Major);

            //Added functionality (IF statement) for a search bar(MN)
            if (!String.IsNullOrEmpty(search))
            {
                applicants = applicants.Where(a => a.LastName.Contains(search) ||
                a.SSN.Contains(search));
                ViewBag.Search = search;
            }
            var Majors = applicants.OrderBy(p => p.Major.MajorName).Select(p => p.Major.MajorName).Distinct();
            if (!String.IsNullOrEmpty(major))
            {
                applicants = applicants.Where(p => p.Major.MajorName == major);
            }
            ViewBag.Major = new SelectList(Majors);
            return View(applicants.ToList());
        }


        public ActionResult ApplicantList(string Major, string searchSSN, string searchLastName)
        {
            //Join to the Majors entity so the results can display the major name
            var applicants = db.Applicants.Include(a => a.Major);



            //If the searchSSN string was filled in, then add a where clause
            if (!String.IsNullOrEmpty(searchSSN))
            {
                applicants = applicants.Where(a => a.SSN.Contains(searchSSN));
                //Not sure why this is in here again
                ViewBag.SearchSSN = searchSSN;
            }
            //If the searchLastName string was filled in, then add a where clause
            if (!String.IsNullOrEmpty(searchLastName))
            {
                applicants = applicants.Where(a => a.LastName.Contains(searchLastName));
                //Not sure why this is in here again
                ViewBag.SearchLastName = searchLastName;
            }


            //Sets up a variable to hold the distinct majors of the records in the result set
            var Majors = applicants.OrderBy(p => p.Major.MajorName).Select(p => p.Major.MajorName).Distinct();

            //If the major (passed parameter) has been filled in, then include it in the where clause
            if (!String.IsNullOrEmpty(Major))
            {
                applicants = applicants.Where(p => p.Major.MajorName == Major);
            }

            //Get the list of majors and put in ViewBag for the next view of the page
            ViewBag.Major = new SelectList(Majors);

            //Execute the query via ToList() and Return the view ApplicantList with that data
            return View(applicants.ToList());
        }


        // GET: Applicants/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Applicant applicant = db.Applicants.Find(id);
            if (applicant == null)
            {
                return HttpNotFound();
            }
            return View(applicant);
        }


      // GET: Applicants/Create
        [AllowAnonymous]
        public ActionResult Create()
        {
            //=======================

           
            //===================
            //Debugging console
            db.Database.Log = Console.Write;
            //TODO: consolidate this for both create and edit
            ViewBag.MajorID = new SelectList(db.Majors, "MajorID", "MajorName");
            
            return View();
        }

        // POST: Applicants/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ApplicantID,FirstName,MiddleName,LastName,SSN,Email,HomePhone,CellPhone,StreetAddress,City,State,Zipcode,DOB,Gender,HighSchoolName,HighSchoolCity,GraduationDate,CurrentGPA,MathSAT,VerbalSAT,MajorID,EnrollmentSemester,EnrollmentYear")] Applicant applicant)
        {

            //Debugging console
            db.Database.Log = Console.Write;
            int CombinedSAT = 0;


            //Prevent duplicate SSNs.  If there are any applicants with the same SSN, error out 
            if (db.Applicants.Any(a => a.SSN == applicant.SSN))
            {
                ModelState.AddModelError("SSN", "An application was already submitted for this SSN.  If you believe this is in error, please contact the GMU Admissions Office");
            }
            else { 
                if (ModelState.IsValid)
                {
                    db.Applicants.Add(applicant);
                    //Fill the SubmissionDate filed with todays date

                    //TODO: Not sure if there is an issue if the submission date wasnt binded
                    applicant.SubmissionDate = DateTime.Now; // Set the submission date to today, including time            

                    CombinedSAT = applicant.MathSAT + applicant.VerbalSAT;
                    //If either the combined SAT or the GPA is below the thresholds, then automatically reject the applicant
                    if ((CombinedSAT < 1000) || (applicant.CurrentGPA <  3.0M))
                    {
                        //TODO: we probably need to create a model for the enrollment decisions
                        applicant.EnrollmentDecision = "Reject";
                        //Put Message in TempData
                        TempData["FailedCriteria"] = "You do not meet GMU's minimum requirement.";

                    }

                    UpdateModel(applicant);


                    db.SaveChanges();

                    //Put the FullName in the TempData
                    TempData["FullName"] = applicant.FirstName + " " + applicant.MiddleName +" " + applicant.LastName;

                    //TODO: set to redirect to a thank you page and pass the viewbag with any rejection message to it.
                    //return RedirectToAction("Index");
                    return Redirect("PostSubmit");
                }

            }

            // Getting this to for repopulating the form if errors.
            ViewBag.MajorID = new SelectList(db.Majors, "MajorID", "MajorName", applicant.MajorID);
            //=====================

            
                //=====================
                return View(applicant);
            
        }

        [AllowAnonymous]
        public ActionResult PostSubmit()
        {

            return View();
        }


        // GET: Applicants/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Applicant applicant = db.Applicants.Find(id);
            if (applicant == null)
            {
                return HttpNotFound();
            }

            ViewBag.MajorID = new SelectList(db.Majors, "MajorID", "MajorName", applicant.MajorID);
            return View(applicant);
        }

        // POST: Applicants/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ApplicantID,FirstName,MiddleName,LastName,SSN,Email,HomePhone,CellPhone,StreetAddress,City,State,Zipcode,DOB,Gender,HighSchoolName,HighSchoolCity,GraduationDate,CurrentGPA,MathSAT,VerbalSAT,MajorID,EnrollmentSemester,EnrollmentYear,SubmissionDate,EnrollmentDecision")] Applicant applicant)
        {
            //TODO: Figure out how to allow the edit of a record w/o editing the SSN
            //Prevent duplicate SSNs.  If there are any applicants with the same SSN, error out 


            //System.Diagnostics.Trace.WriteLine("applicant.SSN" + applicant.SSN);
            //System.Diagnostics.Trace.WriteLine("applicant.ApplicantID" + applicant.ApplicantID);

            // Prevent duplicant SSNs.  If the value for the SSN exists in the database for a different PK value, then error out.  Otherwise, that is ok
            if (db.Applicants.Any(a => a.SSN == applicant.SSN && !(a.ApplicantID==applicant.ApplicantID)))
            {
                ModelState.AddModelError("SSN", "An application was already submitted for this SSN.  If you believe this is in error, please contact the GMU Admissions Office");
            }
            else
            {

                if (ModelState.IsValid)
                {
                    db.Entry(applicant).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("applicantlist");
                }
            }
            ViewBag.MajorID = new SelectList(db.Majors, "MajorID", "MajorID", applicant.MajorID);
            return View(applicant);
        }

        // GET: Applicants/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Applicant applicant = db.Applicants.Find(id);
            if (applicant == null)
            {
                return HttpNotFound();
            }
            return View(applicant);
        }

        // POST: Applicants/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Applicant applicant = db.Applicants.Find(id);
            db.Applicants.Remove(applicant);
            db.SaveChanges();
            return RedirectToAction("Index");
        }






        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
