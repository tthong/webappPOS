﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project2_Group5.Models
{
    public class Major
    {
        //TODO: add friendly names and validations
        [Required]
        public int MajorID { get; set; }
        [Required]
        [Display(Name = "Major Name")]
        [StringLength(255)]
        [Index("Ix_MajorName", Order = 1, IsUnique = true)]
        public String MajorName { get; set; }
        public virtual ICollection<Applicant> Applicants { get; set; }
    }
}