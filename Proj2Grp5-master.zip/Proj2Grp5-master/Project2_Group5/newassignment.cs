using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project2_Group5.Models
{
    public class Applicant
    {

        //TODO: add  validation
        [Required]
        public int ApplicantID { get; set; }
        [Required]
        [Display(Name = "First Name")]
        public String FirstName { get; set; }
        [Required]
        [Display(Name = "Middle Name")]
        public String MiddleName { get; set; }
        [Required]
        [Display(Name = "Last Name")]
        public String LastName { get; set; }

        [Required]
        [RegularExpression(@"^\d{3}-\d{2}-\d{4}$", ErrorMessage = "Invalid Social Security Number, Must be ###-##-####")]
        [StringLength(11)]
        [Index("Ix_SSN", Order = 1, IsUnique = true)]
        [Display(Name = "SSN")]
        public String SSN { get; set; }

        [Required]
        [RegularExpression(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$", ErrorMessage = "Invalid email, must be yourEmail@domain.com")]
        [Display(Name = "Email Address")]
        public String Email { get; set; }
        
        [RegularExpression(@"^((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}$", ErrorMessage = "Invalid phone number, must be ###-###-####")]
        [Display(Name = "Home Phone Number")]
        public String HomePhone { get; set; }
        
        [RegularExpression(@"^((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}$", ErrorMessage = "Invalid phone number, must be ###-###-####")]
        [Display(Name = "Cell Phone Number")]
        public String CellPhone { get; set; }
        
        [Display(Name = "Street Address")]
        public String StreetAddress { get; set; }
        
        public String City { get; set; }
        //TODO: validate state

        public String State { get; set; }
        //TODO: validate zip
        
        [RegularExpression(@"^\d{5}(?:[-\s]\d{4})?$", ErrorMessage = "Invalid zip code")]
        public String Zipcode { get; set; }
        
        [Required]
        //TODO: need regex for standard DOB format.
        [DateMinimumAge(16, ErrorMessage = "Invalid {0}. Age must be greater than {1} years old")]
        [RegularExpression(@"^(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\d\d$", ErrorMessage = "Invalid entry, use MM/DD/YYYY format")]
        [Display(Name = "Date of Birth")]
        public String DOB { get; set; }
       
        public String Gender { get; set; }
        
        [Display(Name = "High School Name")]
        public String HighSchoolName { get; set; }
        
        [Display(Name = "High School City")]
        public String HighSchoolCity { get; set; }
        
        [RegularExpression(@"^(0[1-9]|1[0-2])/(19|2[0-1])\d{2}$", ErrorMessage = "Invalid entry, use MM/YYYY format")]
        [Display(Name = "Graduation Date (MM/YYYY)")]
        public String GraduationDate { get; set; }
        [Required]
        [Display(Name = "Current GPA")]
        [Range(0.0, 4.0, ErrorMessage = "GPA must be between 0.0 and 4.0")]
        public decimal CurrentGPA { get; set; }
        [Required]
        [Display(Name = "Math SAT")]
        [Range(0,800, ErrorMessage = "SAT score must be between 0 and 800")]
        public int MathSAT { get; set; }
        [Required]
        [Display(Name = "Verbal SAT")]
        [Range(0, 800, ErrorMessage = "SAT score must be between 0 and 800")]
        public int VerbalSAT { get; set; }
        //TODO: Make the major dropdown on the edit and create page have a blank entry
        [Display(Name = "Major")]
        public int? MajorID { get; set; }
        //[Display(Name = "Major")]
        public virtual Major Major { get; set; }
        
        [Display(Name = "Enrollment Semester")]
        public String EnrollmentSemester { get; set; }
       
        [Display(Name = "Enrollment Year (YYYY)")]
        [RegularExpression(@"^\d{4}$", ErrorMessage = "Please use the format YYYY")]
        public int? EnrollmentYear { get; set; }

        [Required]
        [Display(Name = "Submission Date")]
        public DateTime SubmissionDate { get; set; }

        //TODO: either need to provide a list of valid values to check against or make a model for the enrollment decision and link/FK to it
        [Display(Name = "Enrollment Decision")]       
        public String EnrollmentDecision { get; set; }



        public class DateMinimumAgeAttribute : ValidationAttribute
        {
            public DateMinimumAgeAttribute(int minimumAge)
            {
                MinimumAge = minimumAge;
                ErrorMessage = "{0} must be greater than {1} years of age";
            }

            public override bool IsValid(object value)
            {
                DateTime date;
                if ((value != null && DateTime.TryParse(value.ToString(), out date)))
                {
                    return date.AddYears(MinimumAge) < DateTime.Now;
                }

                return false;
            }

            public override string FormatErrorMessage(string name)
            {
                return string.Format(ErrorMessageString, name, MinimumAge);
            }

            public int MinimumAge { get; }
        }

    }
}