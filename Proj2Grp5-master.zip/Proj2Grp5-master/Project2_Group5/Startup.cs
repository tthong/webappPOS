﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Project2_Group5.Startup))]
namespace Project2_Group5
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
