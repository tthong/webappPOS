namespace Project2_Group5.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class innitialdb1 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Applicants", "Enrollmentdecision", c => c.String());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Applicants", "Enrollmentdecision", c => c.Int(nullable: false));
        }
    }
}
