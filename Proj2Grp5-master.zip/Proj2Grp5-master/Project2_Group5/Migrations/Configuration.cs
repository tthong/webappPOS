namespace Project2_Group5.Migrations
{
    using Models;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<Project2_Group5.DAL.Project2_Group5Context>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(Project2_Group5.DAL.Project2_Group5Context context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.

            //Seed the school's Majors
            var majors = new List<Major>
            {
                new Major { MajorName = "Information Technology" },
                new Major { MajorName = "Accounting" },
                new Major { MajorName = "Art History" },
                new Major { MajorName = "Biology" },
                new Major { MajorName = "Engineering" },
                new Major { MajorName = "Cyber Security" },
                new Major { MajorName = "Criminology" },
                new Major { MajorName = "Economics" },
                new Major { MajorName = "Earth Science" },
                new Major { MajorName = "Finance" },
                new Major { MajorName = "Forensic Science" },
                new Major { MajorName = "Global Affairs" },
                new Major { MajorName = "History" },
                new Major { MajorName = "Management" },
                new Major { MajorName = "Marketing" },
                new Major { MajorName = "Mathematics" },
                new Major { MajorName = "Music" },
                new Major { MajorName = "Philosophy" },
                new Major { MajorName = "Neuroscience" },
                new Major { MajorName = "Psychology" }
            };
            majors.ForEach(c => context.Majors.AddOrUpdate(p => p.MajorName, c));
            context.SaveChanges();

            var seedApplicants = new List<Applicant>
            {
                new Applicant { FirstName="John", MiddleName="P", LastName="Smith", SSN="123-45-6789", Email="jsmith@gmail.com",DOB="09/01/1998",Gender="Male",
                                CurrentGPA =3.8M, MathSAT=670, VerbalSAT=640,SubmissionDate=DateTime.Now
                },
                new Applicant { FirstName="Bill", MiddleName="Bob", LastName="Booth", SSN="663-23-6621", Email="booth@gmail.com",DOB="05/24/1999",Gender="Male",
                                CurrentGPA =2.5M, MathSAT=600, VerbalSAT=500,SubmissionDate=DateTime.Now,
                                MajorID =3, GraduationDate="05/2020",EnrollmentSemester="Spring",EnrollmentYear=2020,EnrollmentDecision="Reject"
                },
                new Applicant { FirstName="Jill", MiddleName="Jane", LastName="Smith", SSN="321-45-2242", Email="jane.smith@gmail.com",DOB="02/04/1999",Gender="Female",
                                CurrentGPA =3.5M, MathSAT=600, VerbalSAT=440,SubmissionDate=DateTime.Now,
                                MajorID =3, HomePhone="703-422-2323", CellPhone="202-332-2344",StreetAddress="112 Main St",City="Fairfax",State="VA",Zipcode="22032",
                                HighSchoolName="Herndon High School",HighSchoolCity="Herndon",GraduationDate="05/2020",EnrollmentSemester="Fall",EnrollmentYear=2020
                }
            };
            seedApplicants.ForEach(c => context.Applicants.AddOrUpdate(p => p.SSN, c));
            context.SaveChanges();


        }
    }
}
