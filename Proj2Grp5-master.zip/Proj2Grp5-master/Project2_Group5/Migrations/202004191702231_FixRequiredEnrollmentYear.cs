namespace Project2_Group5.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class FixRequiredEnrollmentYear : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Applicants", "EnrollmentYear", c => c.Int());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Applicants", "EnrollmentYear", c => c.Int(nullable: false));
        }
    }
}
