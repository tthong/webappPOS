namespace Project2_Group5.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RemoveRequiredFields : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Applicants", "HomePhone", c => c.String());
            AlterColumn("dbo.Applicants", "CellPhone", c => c.String());
            AlterColumn("dbo.Applicants", "StreetAddress", c => c.String());
            AlterColumn("dbo.Applicants", "City", c => c.String());
            AlterColumn("dbo.Applicants", "State", c => c.String());
            AlterColumn("dbo.Applicants", "Zipcode", c => c.String());
            AlterColumn("dbo.Applicants", "Gender", c => c.String());
            AlterColumn("dbo.Applicants", "HighSchoolName", c => c.String());
            AlterColumn("dbo.Applicants", "HighSchoolCity", c => c.String());
            AlterColumn("dbo.Applicants", "GraduationDate", c => c.String());
            AlterColumn("dbo.Applicants", "EnrollmentSemester", c => c.String());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Applicants", "EnrollmentSemester", c => c.String(nullable: false));
            AlterColumn("dbo.Applicants", "GraduationDate", c => c.String(nullable: false));
            AlterColumn("dbo.Applicants", "HighSchoolCity", c => c.String(nullable: false));
            AlterColumn("dbo.Applicants", "HighSchoolName", c => c.String(nullable: false));
            AlterColumn("dbo.Applicants", "Gender", c => c.String(nullable: false));
            AlterColumn("dbo.Applicants", "Zipcode", c => c.String(nullable: false));
            AlterColumn("dbo.Applicants", "State", c => c.String(nullable: false));
            AlterColumn("dbo.Applicants", "City", c => c.String(nullable: false));
            AlterColumn("dbo.Applicants", "StreetAddress", c => c.String(nullable: false));
            AlterColumn("dbo.Applicants", "CellPhone", c => c.String(nullable: false));
            AlterColumn("dbo.Applicants", "HomePhone", c => c.String(nullable: false));
        }
    }
}
