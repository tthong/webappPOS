namespace Project2_Group5.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AgeMinandZipLength : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Applicants", "Zipcode", c => c.String(maxLength: 5));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Applicants", "Zipcode", c => c.String());
        }
    }
}
