namespace Project2_Group5.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class SubmissionDate : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Applicants", "SubmissionDate", c => c.DateTime(nullable: false));
            DropColumn("dbo.Applicants", "Enrollmentdate");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Applicants", "Enrollmentdate", c => c.DateTime(nullable: false));
            DropColumn("dbo.Applicants", "SubmissionDate");
        }
    }
}
