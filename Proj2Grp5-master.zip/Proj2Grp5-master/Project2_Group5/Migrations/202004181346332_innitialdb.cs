namespace Project2_Group5.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class innitialdb : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Applicants", "Enrollmentdecision", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Applicants", "Enrollmentdecision");
        }
    }
}
