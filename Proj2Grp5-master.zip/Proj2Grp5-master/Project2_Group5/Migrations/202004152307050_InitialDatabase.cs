namespace Project2_Group5.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialDatabase : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Applicants",
                c => new
                    {
                        ApplicantID = c.Int(nullable: false, identity: true),
                        FirstName = c.String(nullable: false),
                        MiddleName = c.String(nullable: false),
                        LastName = c.String(nullable: false),
                        SSN = c.String(nullable: false),
                        Email = c.String(nullable: false),
                        HomePhone = c.String(nullable: false),
                        CellPhone = c.String(nullable: false),
                        StreetAddress = c.String(nullable: false),
                        City = c.String(nullable: false),
                        State = c.String(nullable: false),
                        Zipcode = c.String(nullable: false),
                        DOB = c.String(nullable: false),
                        Gender = c.String(nullable: false),
                        HighSchoolName = c.String(nullable: false),
                        HighSchoolCity = c.String(nullable: false),
                        GraduationDate = c.String(nullable: false),
                        CurrentGPA = c.Decimal(nullable: false, precision: 18, scale: 2),
                        MathSAT = c.Int(nullable: false),
                        VerbalSAT = c.Int(nullable: false),
                        MajorID = c.Int(nullable: false),
                        EnrollmentSemester = c.String(nullable: false),
                        EnrollmentYear = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ApplicantID)
                .ForeignKey("dbo.Majors", t => t.MajorID, cascadeDelete: true)
                .Index(t => t.MajorID);
            
            CreateTable(
                "dbo.Majors",
                c => new
                    {
                        MajorID = c.Int(nullable: false, identity: true),
                        MajorName = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.MajorID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Applicants", "MajorID", "dbo.Majors");
            DropIndex("dbo.Applicants", new[] { "MajorID" });
            DropTable("dbo.Majors");
            DropTable("dbo.Applicants");
        }
    }
}
