namespace Project2_Group5.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EnableMajorFKNull : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Applicants", "MajorID", "dbo.Majors");
            DropIndex("dbo.Applicants", new[] { "MajorID" });
            AlterColumn("dbo.Applicants", "MajorID", c => c.Int());
            CreateIndex("dbo.Applicants", "MajorID");
            AddForeignKey("dbo.Applicants", "MajorID", "dbo.Majors", "MajorID");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Applicants", "MajorID", "dbo.Majors");
            DropIndex("dbo.Applicants", new[] { "MajorID" });
            AlterColumn("dbo.Applicants", "MajorID", c => c.Int(nullable: false));
            CreateIndex("dbo.Applicants", "MajorID");
            AddForeignKey("dbo.Applicants", "MajorID", "dbo.Majors", "MajorID", cascadeDelete: true);
        }
    }
}
