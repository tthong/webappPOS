namespace Project2_Group5.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class uniqueSSNIndex : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Applicants", "SSN", c => c.String(nullable: false, maxLength: 11));
            CreateIndex("dbo.Applicants", "SSN", unique: true, name: "Ix_SSN");
        }
        
        public override void Down()
        {
            DropIndex("dbo.Applicants", "Ix_SSN");
            AlterColumn("dbo.Applicants", "SSN", c => c.String(nullable: false));
        }
    }
}
