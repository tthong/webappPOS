namespace Project2_Group5.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class updateUniqueMajorName : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Majors", "MajorName", c => c.String(nullable: false, maxLength: 255));
            CreateIndex("dbo.Majors", "MajorName", unique: true, name: "Ix_MajorName");
        }
        
        public override void Down()
        {
            DropIndex("dbo.Majors", "Ix_MajorName");
            AlterColumn("dbo.Majors", "MajorName", c => c.String(nullable: false));
        }
    }
}
