namespace Project2_Group5.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class innitilialdb : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Applicants", "Enrollmentdate", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Applicants", "Enrollmentdate");
        }
    }
}
